package edu.uob;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.lang.String;

public class Command {
    private final List<String> tokens;
    private boolean correctCommand = true;
    public Command(String command) {
        tokens = new ArrayList<>();
        lexerCommand2Tokens(command);
    }

    public List<String> getTokens() {
        return tokens;
    }

    public boolean isCorrectCommand() {
        return correctCommand;
    }

    private void lexerCommand2Tokens(String command) {
        for (int i = 0; i < command.length(); i++) {
            if (!correctCommand) {
                return;
            }
            char c = command.charAt(i);
            if (c == ' ') {
                continue;
            }
            if (c == '+' || c == '-') {
                if ((i != command.length() - 1) && StringUtils.isDigit(command.charAt(i + 1))) {
                    i = getDigitToken(i, command);
                    continue;
                }
            }
            if (c == '\'') {
                i = getStringToken(i, command);
                continue;
            }
            if (isComparator(c)) {
                i = getComparatorToken(i, command);
                continue;
            }
            if (StringUtils.isDigit(c) || StringUtils.isLetter(c)) {
                i = getTextToken(i, command);
                continue;
            }
            switch (c) {
                case '*': {tokens.add("*");continue;}
                case ',': {tokens.add(",");continue;}
                case '(': {tokens.add("(");continue;}
                case ')': {tokens.add(")");continue;}
                case ';': {tokens.add(";");continue;}
            }
        }
        if (tokens.isEmpty()) {
            correctCommand = false;
            return;
        }
        String str = tokens.get(tokens.size() - 1);
        if (!str.equals(";")) {
            correctCommand = false;
        }
        return;
    }

    private int getDigitToken(int index, String command) {
        StringBuilder token = new StringBuilder();
        char c = command.charAt(index);
        boolean dotFlag = false;
        if ((c == '-') || (c == '+')) {
            token.append(c);
            index++;
        }
        for (;index < command.length(); index++) {
            c = command.charAt(index);
            if (c == '.') {
                if (!dotFlag) {
                    token.append(c);
                } else {
                    return index - 1;
                }
                continue;
            }
            if (!StringUtils.isDigit(c)) {
                tokens.add(token.toString());
                return index - 1;
            }
            token.append(c);
        }
        return index;
    }

    private int getStringToken(int index, String command) {
        index++;
        StringBuilder token = new StringBuilder();
        token.append('\'');
        char c;
        for (;index < command.length(); index++) {
            c = command.charAt(index);
            if (c == '\t' || c == '\n') {
                correctCommand = false;
                return 0;
            }
            if (c == '\'') {
                token.append(c);
                tokens.add(token.toString());
                return index;
            }
            token.append(c);
        }
        correctCommand = false;
        return index;
    }

    private int getComparatorToken(int index, String command) {
        char c = command.charAt(index);
        char cNext;
        StringBuilder token = new StringBuilder();
        if (c == '>' || c == '<' || c == '=') {
            token.append(c);
            if (index != command.length() - 1) {
                cNext = command.charAt(index + 1);
                if (cNext == '=') {
                    index++;
                    token.append(cNext);
                }
            }

            tokens.add(token.toString());
            return index;
        }
        else {
            if (index == command.length() - 1) {
                correctCommand = false;
                return index;
            }

            cNext = command.charAt(index + 1);
            if (cNext == '=') {
                token.append(c);
                token.append(cNext);
                tokens.add(token.toString());
                index++;
            } else {
                correctCommand = false;
            }
            return index;
        }
    }

    private int getTextToken(int index, String command) {
        boolean allDigit = true;
        int originIndex = index;
        char c;
        StringBuilder token = new StringBuilder();

        for (;index < command.length(); index++) {
            c = command.charAt(index);
            if (StringUtils.isLetter(c)) {
                allDigit = false;
                token.append(c);
                continue;
            }
            if (StringUtils.isDigit(c)) {
                token.append(c);
                continue;
            }
            if (c == '.' && allDigit) {
                return getDigitToken(originIndex, command);
            }
            tokens.add(token.toString());
            return index - 1;
        }

        tokens.add(token.toString());
        return index;
    }

    private boolean isComparator(char c) {
        return (c == '=') || (c == '>') || (c == '<') || (c == '!');
    }
}