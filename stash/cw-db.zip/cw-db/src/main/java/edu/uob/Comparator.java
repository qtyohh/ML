package edu.uob;

import java.util.List;
import java.lang.String;

public class Comparator {
    String attributeName;
    String comparator;
    String value;
    public Comparator(String attributeName, String comparator, String value) {
        this.attributeName = attributeName;
        this.comparator = comparator;
        this.value = value;
    }

    public boolean checkNameExist(List<String> columnNameList) {
        for (String column : columnNameList) {
            if (column.equalsIgnoreCase(attributeName)) {
                return true;
            }
        }
        return false;
    }

    public boolean calculate(List<String> columnNameList, List<String> values) {
        String str = null;
        for (int i = 0; i < columnNameList.size(); i++) {
            if (columnNameList.get(i).equalsIgnoreCase(attributeName)) {
                str = values.get(i);
                break;
            }
        }

        if (str == null) {
            return false;
        }
        return calc(str);
    }

    private boolean calc(String str) {
        if (StringUtils.isStringLiteral(value) && StringUtils.isStringLiteral(str)) {
            return checkString(str);
        }

        if (comparator.equalsIgnoreCase("LIKE")) {
            return str.toUpperCase().contains(value.toUpperCase());
        }

        if (StringUtils.isNumberLiteral(value) && StringUtils.isNumberLiteral(str)) {
            return checkNumber(str);
        }

        if (StringUtils.isBooleanLiteral(value) && StringUtils.isBooleanLiteral(str)) {
            return checkBoolean(str);
        }

        if (comparator.equals("!=")) {
            if (str.equals("true") && value.equals("1")) {
                System.out.println("go in !=");
            }
            return !value.equalsIgnoreCase(str);
        }

        return false;
    }

    private boolean checkString(String str) {
        String val = value.substring(1, value.length() - 1);
        str = str.substring(1, str.length() - 1);

        if (comparator.equals("==")) {
            return str.equals(val);
        }
        if (comparator.equals("!=")) {
            return !str.equals(val);
        }
        if (comparator.equalsIgnoreCase("LIKE")) {
            return str.toUpperCase().contains(val.toUpperCase());
        }
        return false;
    }
    private boolean checkNumber(String str) {
        double strNum = Double.parseDouble(str);
        double valueNum = Double.parseDouble(value);

        return switch (comparator) {
            case "==" -> strNum == valueNum;
            case ">" -> strNum > valueNum;
            case ">=" -> strNum >= valueNum;
            case "<" -> strNum < valueNum;
            case "<=" -> strNum <= valueNum;
            case "!=" -> strNum != valueNum;
            default -> false;
        };
    }
    private boolean checkBoolean(String str) {
        if (comparator.equals("==")) {
            return value.equalsIgnoreCase(str);
        }
        if (comparator.equals("!=")) {
            return !value.equalsIgnoreCase(str);
        }
        return false;
    }

}