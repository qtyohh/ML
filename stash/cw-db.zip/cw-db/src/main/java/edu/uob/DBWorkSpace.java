package edu.uob;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.lang.String;

public class DBWorkSpace implements ParserHandler {

    private Database database = null;
    private final Parser parser;
    private final String storageFolderPath;

    public DBWorkSpace(String storageFolderPath) {
        this.storageFolderPath = storageFolderPath;
        this.parser = new Parser((ParserHandler) this);
    }

    public String workOnCommand(String commandInput) {
        Command command = new Command(commandInput);
        //System.out.println(command.getTokens());
        if (!command.isCorrectCommand()) {
            return "[ERROR]\nInput command error";
        }
        return parser.parseCommand(command.getTokens());
    }

    @Override
    public String useDatabase(String databaseName) {
        databaseName = databaseName.toLowerCase(); // storage in lowercase.
        Path databasePath = Paths.get(this.storageFolderPath, databaseName);
        if (Files.notExists(databasePath)) {
            System.out.println(databasePath.toString());
            return "[ERROR]\nDatabase not exist.";
        }
        database = new Database(databasePath, databaseName);
        return "[OK]";
    }

    @Override
    public String createDatabase(String databaseName) {
        databaseName = databaseName.toLowerCase(); // storage in lowercase.
        Path databasePath = Paths.get(this.storageFolderPath, databaseName);
        if (Files.exists(databasePath)) {
            return "[ERROR]\nThis database has already existed.";
        }

        try {
            Files.createDirectories(databasePath);
            createTableIdCounter(databasePath);

        } catch(IOException ioe) {
            System.out.println("[ERROR]\nCan't seem to create database folder " + databasePath);
        }
        return "[OK]";
    }

    @Override
    public String createTable(String tableName, List<String> columnName) {
        if (database == null) {
            return "[ERROR]\nNo database has been opened.";
        }
        tableName = tableName.toLowerCase(); // storage in lowercase.
        if (!database.addTable(tableName)) {
            return "[ERROR]\nThis table has already existed.";
        }
        for (String column : columnName) {
            if (!database.alterAddColumn(tableName, column)) {
                database.dropTable(tableName);
                return "[ERROR]\nError attribute input.";
            }
        }
        return "[OK]";
    }

    @Override
    public String insertTableValues(String tableName, List<String> valueList) {
        if (database == null) {
            return "[ERROR]\nNo database has been opened.";
        }
        tableName = tableName.toLowerCase(); // storage in lowercase.
        if (!database.addLine(tableName, valueList)) {
            return "[ERROR]\nAdd value to " + tableName + " failed.";
        }
        return "[OK]";
    }

    @Override
    public String selectFromTable(String tableName, List<String> wildAttribList, Condition condition) {
        if (database == null) {
            return "[ERROR]\nNo database has been opened.";
        }
        tableName = tableName.toLowerCase(); // storage in lowercase.
        if (!database.checkTableExist(tableName)) {
            return "[ERROR]\nNo such table.";
        }
        List<String> selectReturnList = database.select(tableName, wildAttribList, condition);
        if (!selectReturnList.isEmpty()) {
            selectReturnList.add(0, "[OK]");
            return String.join("\n", selectReturnList);
        } else {
            return "[ERROR]\nSelect failed.";
        }
    }

    @Override
    public String updateValue(String tableName,
                       List<AbstractMap.SimpleEntry<String, String>> nameValueList,
                       Condition condition) {
        if (database == null) {
            return "[ERROR]\nNo database has been opened.";
        }
        tableName = tableName.toLowerCase(); // storage in lowercase.
        if (!database.updateTable(tableName, nameValueList, condition)) {
            return "[ERROR]\nupdate failed.";
        }
        return "[OK]";
    }

    @Override
    public String alterAdd(String tableName, String columnName) {
        if (database == null) {
            return "[ERROR]\nNo database has been opened.";
        }
        tableName = tableName.toLowerCase(); // storage in lowercase.
        if (!database.alterAddColumn(tableName, columnName)) {
            return "[ERROR]\nAlter add column failed.";
        }
        return "[OK]";
    }

    @Override
    public String alterDrop(String tableName, String columnName) {
        if (database == null) {
            return "[ERROR]\nNo database has been opened.";
        }
        tableName = tableName.toLowerCase(); // storage in lowercase.
        if (!database.alterDropColumn(tableName, columnName)) {
            return "[ERROR]\nAlter drop column failed.";
        }
        return "[OK]";
    }

    @Override
    public String deleteFromTable(String tableName, Condition condition) {
        if (database == null) {
            return "[ERROR]\nNo database has been opened.";
        }
        tableName = tableName.toLowerCase(); // storage in lowercase.
        if (!database.deleteLine(tableName, condition)) {
            return "[ERROR]\nDelete line from table failed.";
        }
        return "[OK]";
    }

    @Override
    public String dropDatabase(String databaseName) {
        databaseName = databaseName.toLowerCase(); // storage in lowercase.
        Path databaseFolderPath = Paths.get(storageFolderPath, databaseName);
        try {
            // 使用 Files.walkFileTree 递归删除文件、子目录及根目录
            Files.walkFileTree(databaseFolderPath, new SimpleFileVisitor<Path>() {
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    // 删除文件
                    Files.delete(file);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                    // 文件夹内容删完后再删自身
                    if (exc == null) {
                        Files.delete(dir);
                        return FileVisitResult.CONTINUE;
                    }
                    throw exc;
                }
            });
        } catch (IOException e) {
            return "[ERROR]";
        }

        if (database != null && database.getDatabaseName().equalsIgnoreCase(databaseName)) {
            database = null;
        }
        return "[OK]";
    }


    @Override
    public String dropTable(String tableName) {
        if (database == null) {
            return "[ERROR]\nNo database has been opened.";
        }
        tableName = tableName.toLowerCase(); // storage in lowercase.
        if (!database.dropTable(tableName)) {
            return "[ERROR]\nDelete table failed.";
        }
        return "[OK]";
    }

    @Override
    public String joinTwoTable(String tableName1, String tableName2, String attributeName1, String attributeName2) {
        if (database == null) {
            return "[ERROR]\nNo database has been opened.";
        }
        tableName1 = tableName1.toLowerCase(); // storage in lowercase.
        tableName2 = tableName2.toLowerCase(); // storage in lowercase.

        List<String> joinList = new ArrayList<>(
                database.joinTable(tableName1, tableName2, attributeName1, attributeName2));
        if (!joinList.isEmpty()) {
            joinList.add(0,"[OK]");
            return String.join("\n", joinList);
        } else {
            return "[ERROR]\nJoin failed.";
        }
    }

    private void createTableIdCounter(Path databasePath) {
        Path filePath = databasePath.resolve("tableIdCounter_.tab");
        try {
            Files.createFile(filePath);

        } catch(IOException ioe) {
            System.out.println("[ERROR]\n");
        }
    }

}