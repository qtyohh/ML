package edu.uob;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.lang.String;

public class Parser {
    /*
    *  Call back functions are in the order of:
    * <Use> | <Create> | <Drop> | <Alter> | <Insert> | <Select> | <Update> | <Delete> | <Join>
    * */
    private final ParserHandler handler;

    public Parser(ParserHandler handler) {
        this.handler = handler;
    }

    public String parseCommand(List<String> tokens) {
        if (tokens == null || tokens.isEmpty()) {
            return "[ERROR]\nEmpty token list.";
        }

        String commandType = tokens.get(0).toUpperCase();

        return switch (commandType) {
            case "USE"    -> useCommand(tokens);
            case "CREATE" -> createCommand(tokens);
            case "INSERT" -> insertCommand(tokens);
            case "SELECT" -> selectCommand(tokens);
            case "UPDATE" -> updateCommand(tokens);
            case "ALTER"  -> alterCommand(tokens);
            case "DELETE" -> deleteCommand(tokens);
            case "DROP"   -> dropCommand(tokens);
            case "JOIN"   -> joinCommand(tokens);
            default       -> "[ERROR]\nError command type: " + commandType;
        };
    }

    private String useCommand(List<String> tokens) {
        if (tokens.size() == 3) {
            String str = tokens.get(1);
            if (!StringUtils.isPlainText(str)) {
                return "[ERROR]\nError database name.";
            }
            return handler.useDatabase(str);
        }
        return "[ERROR]\nError use command input.";
    }
    private String createCommand(List<String> tokens) {
        if (tokens.size() < 4) {
            return "[ERROR]\nError create command input.";
        }

        String str = tokens.get(1);

        if (str.equalsIgnoreCase("DATABASE")) {
            str = tokens.get(2);
            if (tokens.size() != 4) {
                return "[ERROR]\nError create database command.";
            }

            if (!StringUtils.isPlainText(str)) {
                return "[ERROR]\nError database name input.";
            }
            return handler.createDatabase(str);
        }

        if (str.equalsIgnoreCase("TABLE")) {
            str = tokens.get(2);
            List<String> columnNames = new ArrayList<>();
            if (!StringUtils.isPlainText(str)) {
                return "[ERROR]\nError table name input.";
            }

            // create with no attribute
            if (tokens.size() == 4) {
                return handler.createTable(str, columnNames);
            }

            str = tokens.get(3);
            String str2 = tokens.get(tokens.size() - 2);
            if ((!str.equals("(")) || (!str2.equals(")"))) {
                return "[ERROR]\nError create table attribute input.";
            }

            columnNames = StringUtils.getAttributeList(tokens, 4, tokens.size() - 3);
            if (columnNames.isEmpty()) {
                return "[ERROR]\nError create table attribute input.";
            }
            //create with attributeList
            str = tokens.get(2);
            return handler.createTable(str, columnNames);
        }
        return "[ERROR]\nError create command input.";
    }
    private String insertCommand(List<String> tokens) {
        if (tokens.size() < 7) {
            return "[ERROR]\nError insert command input.";
        }

        String str = tokens.get(1);
        String tableName;
        if (!str.equalsIgnoreCase("INTO")) {
            return "[ERROR]\nError insert command input.";
        }

        str = tokens.get(2);
        if (!StringUtils.isPlainText(str)) {
            return "[ERROR]\nError table name input.";
        }
        tableName = str;

        str = tokens.get(3);
        if (!str.equalsIgnoreCase("VALUES")) {
            return "[ERROR]\nError insert command input.";
        }

        str = tokens.get(4);
        if (!str.equals("(")) {
            return "[ERROR]\nError insert command input.";
        }
        str = tokens.get(tokens.size() - 2);
        if (!str.equals(")")) {
            return "[ERROR]\nError insert command input.";
        }

        List<String> valueList = StringUtils.getValueList(tokens, 5, tokens.size() - 3);
        if (valueList.isEmpty()) {
            return "[ERROR]\nError values input in insert command.";
        }

        return handler.insertTableValues(tableName, valueList);
    }
    private String selectCommand(List<String> tokens) {
        String str;
        int index = 1;
        for (;index < tokens.size(); index++) {
            str = tokens.get(index);
            if (str.equalsIgnoreCase("FROM")) {
                break;
            }
        }
        if (index == 1 || index == tokens.size()) {
            return "[ERROR]\nError select command input.";
        }
        //get WildAttribList
        List<String> wildAttribList = StringUtils.getWildAttribList(tokens, 1, index - 1);

        if (wildAttribList.isEmpty()) {
            return "[ERROR]\nError attribute in select command.";
        }

        //table name
        String tabelName;
        str = tokens.get(++index);
        if (!StringUtils.isPlainText(str)) {
            return "[ERROR]\nError table name in select command.";
        }
        tabelName = str;

        // check if there is a WHERE
        str = tokens.get(++index);
        Condition condition = new Condition();

        if (str.equals(";")) {
            return handler.selectFromTable(tabelName, wildAttribList, condition);
        }
        if (!str.equalsIgnoreCase("WHERE")) {
            return "[ERROR]\nError select command input.";
        }

        // get conditions
        index++;
        if (condition.buildTree(tokens, index, tokens.size() - 2, false)) {
            return handler.selectFromTable(tabelName, wildAttribList, condition);
        } else {
            return "[ERROR]\nError condition input.";
        }
    }
    private String updateCommand(List<String> tokens) {
        if (tokens.size() < 5) {
            return "[ERROR]\nError update command input.";
        }

        int index = 1;
        String str = tokens.get(index);
        if (!StringUtils.isPlainText(str)) {
            return "[ERROR]\nError table name in update command.";
        }
        String tableName = str;

        str = tokens.get(++index);
        if (!str.equalsIgnoreCase("SET")) {
            return "[ERROR]\nError update command input.";
        }

        for (;index < tokens.size(); index++) {
            str = tokens.get(index);
            if (str.equalsIgnoreCase("WHERE")) {
                break;
            }
        }
        if (index == tokens.size()) {
            return "[ERROR]\nError table name in update command.";
        }

        List<AbstractMap.SimpleEntry<String, String>> nameValueList =
                StringUtils.getNameValueList(tokens, 3, index - 1);
        if (nameValueList.isEmpty()) {
            return "[ERROR]\nError name value list in update command.";
        }

        Condition condition = new Condition();
        if (!condition.buildTree(tokens, index + 1, tokens.size() - 2, false)) {
            return "[ERROR]\nError condition in update command.";
        }

        return handler.updateValue(tableName, nameValueList, condition);
    }
    private String alterCommand(List<String> tokens) {
        if (tokens.size() != 6) {
            return "[ERROR]\nError alter command input.";
        }

        int index = 1;
        String str = tokens.get(index);
        if (!str.equalsIgnoreCase("TABLE")) {
            return "[ERROR]\nError alter command input.";
        }

        str = tokens.get(++index);
        if (!StringUtils.isPlainText(str)) {
            return "[ERROR]\nError table name in alter command.";
        }
        String tableName = str;

        ++index;
        str = tokens.get(index + 1);
        if (!StringUtils.isPlainText(str)) {
            return "[ERROR]\nError attribute name in alter command.";
        }

        str = tokens.get(index);
        if (str.equalsIgnoreCase("ADD")) {
            return handler.alterAdd(tableName, tokens.get(index + 1));
        } else if (str.equalsIgnoreCase("DROP")) {
            return handler.alterDrop(tableName, tokens.get(index + 1));
        } else {
            return "[ERROR]\nError alter type command input.";
        }
    }
    private String deleteCommand(List<String> tokens) {
        int index = 1;
        String str = tokens.get(index);
        if (!str.equalsIgnoreCase("FROM")) {
            return "[ERROR]\nError delete command input.";
        }

        str = tokens.get(++index);
        if (!StringUtils.isPlainText(str)) {
            return "[ERROR]\nError table name in delete command.";
        }
        String tableName = str;

        str = tokens.get(++index);
        if (!str.equalsIgnoreCase("WHERE")) {
            return "[ERROR]\nError delete command input.";
        }

        Condition condition = new Condition();
        if (!condition.buildTree(tokens, index + 1, tokens.size() - 2, false)) {
            return "[ERROR]\nError condition in delete command.";
        }
        return handler.deleteFromTable(tableName, condition);
    }
    private String dropCommand(List<String> tokens) {
        if (tokens.size() != 4) {
            return "[ERROR]\nError drop command input.";
        }

        String str = tokens.get(1);
        if (str.equalsIgnoreCase("DATABASE")) {
            str = tokens.get(2);
            if (!StringUtils.isPlainText(str)) {
                return "[ERROR]\nError database name in drop command.";
            }
            return handler.dropDatabase(str);
        } else if (str.equalsIgnoreCase("TABLE")) {
            str = tokens.get(2);
            if (!StringUtils.isPlainText(str)) {
                return "[ERROR]\nError table name in drop command.";
            }
            return handler.dropTable(str);
        } else {
            return "[ERROR]\nError drop command input.";
        }
    }
    private String joinCommand(List<String> tokens) {
        if (tokens.size() != 9) {
            return "[ERROR]\nError join command input.";
        }

        if (!StringUtils.isPlainText(tokens.get(1)) || !StringUtils.isPlainText(tokens.get(3))) {
            return "[ERROR]\nError table name in join command.";
        }
        if (!tokens.get(2).equalsIgnoreCase("AND") ||
                !tokens.get(4).equalsIgnoreCase("ON") ||
                !tokens.get(6).equalsIgnoreCase("AND")) {
            return "Error join command input.";
        }
        if (!StringUtils.isPlainText(tokens.get(5)) || !StringUtils.isPlainText(tokens.get(7))) {
            return "[ERROR]\nError attribute name in join command.";
        }
        return handler.joinTwoTable(tokens.get(1), tokens.get(3), tokens.get(5), tokens.get(7));
    }

}