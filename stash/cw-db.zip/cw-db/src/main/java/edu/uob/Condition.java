package edu.uob;

import java.util.ArrayList;
import java.util.List;
import java.lang.String;

public class Condition {
    private List<Condition> childList;
    private List<String> boolOperatorList;
    private boolean isLeaf;
    private Comparator comparator;
    private int endIndex;

    public Condition() {
        this.childList = new ArrayList<>();
        this.boolOperatorList = new ArrayList<>();
        boolOperatorList.add("AND");
        this.isLeaf = false;
    }

    public boolean buildTree(List<String> tokens, int start, int end, boolean hasBracket) {
        if (start > end) {return false;}
        int index;
        String str;
        Condition child;
        boolean getOperator = true;

        for (index = start; index <= end; index++) {
            str = tokens.get(index);
            if (str.equals("(")) {
                if (!getOperator) {return false;}
                child = new Condition();
                this.childList.add(child);
                if(!child.buildTree(tokens, index + 1, end, true)) {return false;}
                index = child.endIndex;
                getOperator = false;
                continue;
            }
            if (str.equals(")")) {
                if (childList.isEmpty()) {return false;}
                if (hasBracket) {
                    this.endIndex = index;
                    return true;
                } else {return false;}
            }
            if (StringUtils.isBoolOperator(str)) {
                if (getOperator) {return false;}
                this.boolOperatorList.add(str);
                getOperator = true;
                continue;
            }
            if (tryGetComparator(tokens, index)) {
                if (!getOperator) {return false;}
                child = new Condition();
                this.childList.add(child);
                child.isLeaf = true;
                child.comparator = new Comparator(tokens.get(index), tokens.get(index + 1), tokens.get(index + 2));
                getOperator = false;
                index += 2;
            } else {return false;}
        }
        if (hasBracket) {return  false;}
        this.endIndex = end;
        return true;
    }

    public void printTree() {
        System.out.println("Node info:");
        System.out.println(childList);
        System.out.println(boolOperatorList);
        System.out.println("isLeaf: " + isLeaf);
        if (isLeaf) {
            System.out.println(comparator.attributeName + " " + comparator.comparator + " " + comparator.value);
        }
        System.out.println();

        for (Condition child : childList) {
            child.printTree();
        }
    }

    public boolean calculate(List<String> columnList, List<String> valueList) {
        if (this.isLeaf) {
            return this.comparator.calculate(columnList, valueList);
        }
        boolean calcAns = true;
        for (int i = 0; i < this.childList.size(); i++) {
            if (this.boolOperatorList.get(i).equalsIgnoreCase("AND")) {
                calcAns &= this.childList.get(i).calculate(columnList, valueList);
            } else {
                calcAns |= this.childList.get(i).calculate(columnList, valueList);
            }
        }
        return calcAns;
    }

    public boolean checkNameExist(List<String> columnNameList) {
        if (this.isLeaf) {
            return this.comparator.checkNameExist(columnNameList);
        }
        boolean retFlag = true;
        for (Condition child : childList) {
            retFlag &= child.checkNameExist(columnNameList);
        }
        return retFlag;
    }

    /*
    *
    * */

    private boolean tryGetComparator(List<String> tokens, int index) {
        if (index + 2 >= tokens.size()) {
            return false;
        }
        String str1 = tokens.get(index);
        String str2 = tokens.get(index + 1);
        String str3 = tokens.get(index + 2);
        return  (StringUtils.isPlainText(str1) && isComparator(str2) && StringUtils.isValue(str3));
    }

    private boolean isComparator(String token) {
        if (token.equalsIgnoreCase("LIKE")) {
            return true;
        }
        char c = token.charAt(0);
        return (c == '=') || (c == '>') || (c == '<') || (c == '!');
    }

}