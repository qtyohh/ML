package edu.uob;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.lang.String;

public class StringUtils {
    public static List<AbstractMap.SimpleEntry<String, String>> getNameValueList (List<String> tokens,
                                                                                  int start,
                                                                                  int end
    ) {
        int index = start;
        String str, str1, str2;
        List<AbstractMap.SimpleEntry<String, String>> nameValueList = new ArrayList<>();
        List<AbstractMap.SimpleEntry<String, String>> errorReturn = new ArrayList<>();

        while (index <= end) {
            if (end - index < 2) {
                return errorReturn;
            }

            str = tokens.get(index);
            str1 = tokens.get(index + 1);
            str2 = tokens.get(index + 2);
            if (!isPlainText(str) || !str1.equals("=") || !isValue(str2)) {
                return errorReturn;
            }
            nameValueList.add(new AbstractMap.SimpleEntry<String, String>(str, str2));
            index += 2;
            if (index == end) {
                return nameValueList;
            }
            str = tokens.get(++index);
            if (!str.equals(",")) {
                return errorReturn;
            }
            index++;
        }
        return errorReturn;
    }
    public static List<String> getWildAttribList (List<String> tokens, int start, int end) {
        String str = tokens.get(start);
        List<String> list = new ArrayList<>();
        List<String> errorReturn = new ArrayList<>();
        if (str.equals("*")) {
            if (start == end) {
                list.add(str);
                return list;
            } else {
                return errorReturn;
            }
        }
        return getAttributeList(tokens, start, end);
    }
    public static List<String> getAttributeList(List<String> tokens, int start, int end) {
        String str;
        List<String> attributeList = new ArrayList<>();
        List<String> errorReturn = new ArrayList<>();

        for (int i = start; i <= end; i++) {
            str = tokens.get(i);
            if (!isPlainText(str)) {
                return errorReturn;
            }
            attributeList.add(str);
            i++;
            if (i > end) {
                return attributeList;
            }
            str = tokens.get(i);
            if (!str.equals(",")) {
                return errorReturn;
            }
        }
        return errorReturn;
    }
    public static List<String> getValueList(List<String> tokens, int start, int end) {
        String str;
        List<String> valueList = new ArrayList<>();
        List<String> errorReturn = new ArrayList<>();

        for (int i = start; i <= end; i++) {
            str = tokens.get(i);
            if (!isValue(str)) {
                return errorReturn;
            }

            valueList.add(str);
            i++;
            if (i > end) {
                return valueList;
            }

            str = tokens.get(i);
            if (!str.equals(",")) {
                return errorReturn;
            }
        }

        return errorReturn;
    }

    public static boolean isKeyWord(String token) {
        List<String> keyword = Arrays.asList("SELECT","USE","CREATE","DELETE","ALTER","UPDATE","INSERT","JOIN",
                "DROP","ADD","DATABASE","TABLE","FROM","WHERE","INTO","ON","SET","LIKE",
                "NULL","AND","OR","TRUE","FALSE");
        return keyword.contains(token.toUpperCase());
    }
    public static boolean isValue(String token) {
        if (token.isEmpty()) {
            return false;
        }
        if (token.equalsIgnoreCase("NULL")) {
            return true;
        }

        return isStringLiteral(token) || isBooleanLiteral(token) || isFloatLiteral(token) || isIntegerLiteral(token);
    }
    public static boolean isPlainText(String token) {
        if (isKeyWord(token)) {
            return false;
        }
        for (char c : token.toCharArray()) {
            if ((!isLetter(c)) && (!isDigit(c))) {
                return false;
            }
        }
        return true;
    }
    public static boolean isStringLiteral(String token) {
        int len = token.length();
        if (len < 2) {
            return false;
        }
        return token.charAt(0) == '\'' && token.charAt(len - 1) == '\'';
    }
    public static boolean isBoolOperator(String token) {
        return token.equalsIgnoreCase("AND") || token.equalsIgnoreCase("OR");
    }
    public static boolean isBooleanLiteral(String token) {
        return token.equalsIgnoreCase("TRUE") || token.equalsIgnoreCase("FALSE");
    }
    public static boolean isFloatLiteral(String token) {
        if (token.length() < 3) {
            return false;
        }
        boolean digitBeforeDot = false;
        boolean digitAfterDot = false;
        boolean dotFlag = false;
        int index = 0;

        if (token.charAt(0) == '-' || token.charAt(0) == '+') {
            index++;
        }

        for(;index < token.length(); index++) {
            char c = token.charAt(index);
            if (c == '.') {
                if (dotFlag) {
                    return false;
                } else {
                    dotFlag = true;
                    continue;
                }
            }

            if (!dotFlag) {
                if (isDigit(c)) {digitBeforeDot = true;}
                else {return false;}
            }
            else {
                if (isDigit(c)) {digitAfterDot = true;}
                else {return false;}
            }
        }

        return digitBeforeDot &&  dotFlag && digitAfterDot;
    }
    public static boolean isIntegerLiteral(String token) {
        if (token.isEmpty()) {
            return false;
        }
        boolean digitFlag = false;
        int index = 0;

        if (token.charAt(0) == '-' || token.charAt(0) == '+') {
            index++;
        }
        for (;index < token.length(); index++) {
            char c = token.charAt(index);
            if (isDigit(c)) {
                digitFlag = true;
            }
            else {
                return false;
            }
        }
        return digitFlag;
    }
    public static boolean isNumberLiteral(String token) {
        return isFloatLiteral(token) || isIntegerLiteral(token);
    }
    public static boolean isLetter(char c) {
        return ((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z'));
    }
    public static boolean isDigit(char c) {
        return (c >= '0') && (c <= '9');
    }
}