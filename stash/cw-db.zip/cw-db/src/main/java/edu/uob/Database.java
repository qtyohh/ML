package edu.uob;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.lang.String;

public class Database {
    private final String databaseName;
    private List<Table> tableList;
    private final Path databaseStoragePath;
    private List<AbstractMap.SimpleEntry<String, Integer>> tableIdCounter;

    public Database(Path databaseStoragePath, String databaseName) {
        this.databaseName = databaseName;
        this.databaseStoragePath = databaseStoragePath;
        this.tableList = new ArrayList<Table>();
        this.tableIdCounter = new ArrayList<>();
        initDatabase();
    }

    public void initDatabase() {
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(databaseStoragePath, "*.tab")) {
            for (Path filePath : stream) {
                String tableName = filePath.getFileName().toString().replaceFirst("\\.tab$", "");
                if (tableName.equalsIgnoreCase("tableIdCounter_")) {
                    tableIdCounterReadIn(filePath);
                    continue;
                }
                Table table = new Table(tableName);
                List<String> lines = Files.readAllLines(filePath);
                table.setColumnNameList(lines.get(0));
                for (int i = 1; i < lines.size(); i++) {
                    List<String> columns = Arrays.asList(lines.get(i).split("\t"));
                    table.addLine(columns);
                }
                tableList.add(table);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean addTable(String tableName) {
        for (Table table : tableList) {
            if (table.getTableName().equalsIgnoreCase(tableName)) {
                return false;
            }
        }
        Table table = new Table(tableName);
        table.addColumn("id");
        tableList.add(table);
        writeTableFile(table);
        tableIdCounter.add(new AbstractMap.SimpleEntry<>(tableName, 0));
        writeIdCounter();
        return true;
    }

    public boolean dropTable(String tableName) {
        Table table = getTable(tableName);
        if (table == null) {
            return false;
        }
        deleteTabelFile(tableName);
        tableList.remove(table);
        for (AbstractMap.SimpleEntry<String, Integer> entry : tableIdCounter) {
            if (entry.getKey().equals(tableName)) {
                tableIdCounter.remove(entry);
                writeIdCounter();
                break;
            }
        }
        return true;
    }

    public boolean addLine(String tableName, List<String> line) {
        Table table = getTable(tableName);
        if (table == null) {
            return false;
        }
        for (AbstractMap.SimpleEntry<String, Integer> entry : tableIdCounter) {
            if (entry.getKey().equals(tableName)) {
                int id = entry.getValue() + 1;
                line.add(0, String.valueOf(id));
                if (!table.addLine(line)) {
                    return false;
                }
                writeTableFile(table);
                entry.setValue(id);
                writeIdCounter();
                return true;
            }
        }
        return false;
    }

    public boolean deleteLine(String tableName, Condition condition) {
        Table table = getTable(tableName);
        if (table == null) {
            return false;
        }
        if (!table.deleteLine(condition)) {
            return false;
        }
        writeTableFile(table);
        return true;
    }

    public boolean updateTable(String tableName,
                                       List<AbstractMap.SimpleEntry<String, String>> nameValueList,
                                       Condition condition) {
        Table table = getTable(tableName);
        if (table == null) {
            return false;
        }
        for (AbstractMap.SimpleEntry<String, String> pair : nameValueList) {
            if (!table.checkColumnNameExist(pair.getKey())) {
                return false;
            }
        }
        if (table.updateLine(nameValueList, condition)) {
            writeTableFile(table);
            return true;
        }
        return false;
    }

    public boolean alterAddColumn(String tableName, String columnName) {
        Table table = getTable(tableName);
        if (table == null) {
            return false;
        }
        if (table.checkColumnNameExist(columnName)) {
            return false;
        }
        table.addColumn(columnName);
        writeTableFile(table);
        return true;
    }

    public boolean alterDropColumn(String tableName, String columnName) {
        Table table = getTable(tableName);
        if (table == null) {
            return false;
        }
        if (!table.checkColumnNameExist(columnName)) {
            return false;
        }
        if (table.dropColumn(columnName)) {
            writeTableFile(table);
            return true;
        }
        return false;
    }

    public List<String> select(String tableName, List<String> wildAttribList, Condition condition) {
        Table table = getTable(tableName);
        List<String> selectRet = new ArrayList<>();
        if (table == null) {
            return selectRet;
        }
        for (String attribute : wildAttribList) {
            if (attribute.equals("*")) {
                break;
            }
            if (!table.checkColumnNameExist(attribute)) {
                return selectRet;
            }
        }
        selectRet = table.selectLines(wildAttribList, condition);
        return selectRet;
    }

    public List<String> joinTable(String tableName1, String tableName2,
                                  String attributeName1, String attributeName2) {
        Table table1 = getTable(tableName1), table2 = getTable(tableName2);
        if (table1 == null || table2 == null) {
            return null;
        }
        if (!table1.checkColumnNameExist(attributeName1) || !table2.checkColumnNameExist(attributeName2)) {
            return null;
        }

        List<String> retList = new ArrayList<>();
        List<String> line1, line2;
        StringBuilder newLine = new StringBuilder();
        int id = 1;
        int index1 = table1.getColumnIndex(attributeName1), index2 = table2.getColumnIndex(attributeName2);

        newLine.append("id\t");
        newLine.append(String.join("\t", table1.getColumnNameListForJoin(attributeName1)));
        newLine.append("\t");
        newLine.append(String.join("\t", table2.getColumnNameListForJoin(attributeName2)));
        retList.add(newLine.toString());

        for (int i = 0; i < table1.getLineNumber(); i++) {
            line1 = table1.getLineInTokens(i);
            for (int j = 0; j < table2.getLineNumber(); j++) {
                line2 = table2.getLineInTokens(j);
                if(!line1.get(index1).equalsIgnoreCase(line2.get(index2))) {
                    continue;
                }
                newLine = new StringBuilder();
                newLine.append(id);
                newLine.append(getJoinLine(line1, index1));
                newLine.append(getJoinLine(line2, index2));
                id++;
                System.out.println(newLine);
                retList.add(newLine.toString());
            }
        }
        return retList;
    }

    public boolean checkTableExist(String tableName) {
        for (Table table : tableList) {
            if(table.getTableName().equalsIgnoreCase(tableName)) {
                return true;
            }
        }
        return false;
    }

    private void tableIdCounterReadIn(Path filePath) throws IOException {
        List<String> lines = Files.readAllLines(filePath);
        String[] tokens;
        for (String line : lines) {
            tokens = line.split("\t");
            tableIdCounter.add(new AbstractMap.SimpleEntry<>(tokens[0], Integer.parseInt(tokens[1])));
        }
    }

    private String getJoinLine(List<String> line, int index) {
        StringBuilder newLine = new StringBuilder();
        for (int k = 1; k < line.size(); k++) {
            if (k != index) {
                String token = line.get(k);
                if (StringUtils.isStringLiteral(token)) {
                    token = token.substring(1, token.length() - 1);
                }
                newLine.append("\t");
                newLine.append(token);
            }
        }
        return newLine.toString();
    }

    private void createTabelFile(String tableName) {
        String tableFile = tableName + ".tab";
        Path tabFilePath = databaseStoragePath.resolve(tableFile);
        try {
            Files.createFile(tabFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void deleteTabelFile(String tableName) {
        String tableFile = tableName + ".tab";
        Path tabFilePath = databaseStoragePath.resolve(tableFile);
        try {
            Files.deleteIfExists(tabFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void writeTableFile(Table table) {
        String tableFile = table.getTableName() + ".tab";
        Path tabFilePath = databaseStoragePath.resolve(tableFile);
        try {
            Files.write(
                    tabFilePath,
                    table.getDataInListString(),
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING
            );

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void writeIdCounter() {
        Path tabFilePath = databaseStoragePath.resolve("tableIdCounter_.tab");
        StringBuilder counterStr = new StringBuilder();
        for (AbstractMap.SimpleEntry<String, Integer> pair : tableIdCounter) {
            counterStr.append(pair.getKey());
            counterStr.append("\t");
            counterStr.append(pair.getValue());
            counterStr.append("\n");
        }
        try {
            Files.writeString(
                    tabFilePath,
                    counterStr.toString(),
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING
            );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Table getTable(String tableName) {
        for (Table table : tableList) {
            if (table.getTableName().equalsIgnoreCase(tableName)) {
                return  table;
            }
        }
        return null;
    }

    public String getDatabaseName() {
        return databaseName;
    }
}