package edu.uob;

import java.util.*;
import java.lang.String;

public class Table {
    private final String tableName;
    private List<String> columnNameList;
    private List<List<String>> tableData;

    public Table(String tableName) {
        this.tableName = tableName;
        this.tableData = new ArrayList<>();
        columnNameList = new ArrayList<>();
    }

    public String getTableName() {
        return tableName;
    }

    public boolean addLine(List<String> data) {
        if (data.size() != columnNameList.size()) {
            return false;
        }
        tableData.add(data);
        return true;
    }

    public boolean deleteLine(Condition condition) {
        tableData.removeIf(line -> condition.calculate(columnNameList, line));
        return true;
    }

    public void addColumn(String columnName) {
        columnNameList.add(columnName);
        for (List<String> line : tableData) {
            line.add("NULL");
        }
    }

    public boolean dropColumn(String columnName) {
        if (columnName.equalsIgnoreCase("id")) {
            return false;
        }
        int index = getColumnIndex(columnName);
        columnNameList.remove(index);
        for (List<String> line : tableData) {
            line.remove(index);
        }
        return true;
    }

    public List<String> selectLines(List<String> wildAttribList, Condition condition) {
        List<Integer> selectColumn = selectColumnName(wildAttribList);
        List<String> selectRet = new ArrayList<>();
        List<String> selectLine = new ArrayList<>();
        if (!condition.checkNameExist(columnNameList)) {
            return selectRet;
        }
        for (int i : selectColumn) {
            selectLine.add(columnNameList.get(i));
        }
        selectRet.add(String.join("\t", selectLine));

        for (List<String> line : tableData) {
            if (!condition.calculate(columnNameList, line)) {
                continue;
            }
            selectLine = new ArrayList<>();
            for (int i : selectColumn) {
                String token = line.get(i);
                if (StringUtils.isStringLiteral(token)) {
                    selectLine.add(token.substring(1, token.length() - 1));
                } else {
                    selectLine.add(token);
                }
            }
            selectRet.add(String.join("\t", selectLine));
        }
        return selectRet;
    }

    public boolean updateLine(List<AbstractMap.SimpleEntry<String, String>> nameValueList,
                           Condition condition) {
        for (AbstractMap.SimpleEntry<String, String> pair : nameValueList) {
            if (pair.getKey().equalsIgnoreCase("id")) {
                return false;
            }
        }
        for (List<String> line : tableData) {
            if (!condition.calculate(columnNameList, line)) {
                continue;
            }
            for (AbstractMap.SimpleEntry<String, String> pair : nameValueList) {
                int index = getColumnIndex(pair.getKey());
                line.set(index, pair.getValue());
            }
        }
        return true;
    }

    public int getColumnIndex(String name) {
        for (int i = 0;i < columnNameList.size(); i++) {
            if (columnNameList.get(i).equalsIgnoreCase(name)) {
                return i;
            }
        }
        return 0;
    }

    public void setColumnNameList(String nameList) {
        columnNameList = Arrays.asList(nameList.split("\t"));
    }

    public boolean checkColumnNameExist(String name) {
        for (String columnName : columnNameList) {
            if (columnName.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    public List<Integer> selectColumnName(List<String> wildAttribList) {
        List<Integer> columnList = new ArrayList<>();
        boolean ifSelectAll = wildAttribList.contains("*");
        for (String attribute : wildAttribList) {
            for (int i = 0; i < columnNameList.size(); i++) {
                if (ifSelectAll || attribute.equalsIgnoreCase(columnNameList.get(i))) {
                    columnList.add(i);
                }
            }
        }
        return columnList;
    }

    public List<String> getDataInListString() {
        List<String> lineList = new ArrayList<>();
        lineList.add(String.join("\t", columnNameList));
        for (List<String> line : tableData) {
            lineList.add(String.join("\t", line));
        }
        return lineList;
    }

    public List<String> getLineInTokens(int index) {
        if (index >= 0 && index <tableData.size()) {
            return tableData.get(index);
        }
        return null;
    }

    public List<String> getColumnNameListForJoin(String attributeName) {
        List<String> retList = new ArrayList<>();
        StringBuilder str;
        for (String columnName : columnNameList) {
            if (columnName.equalsIgnoreCase(attributeName) || columnName.equals("id")) {
                continue;
            }
            str = new StringBuilder();
            str.append(tableName);
            str.append(".");
            str.append(columnName);
            retList.add(str.toString());
        }
        return retList;
    }

    public int getLineNumber() {
        return tableData.size();
    }

}