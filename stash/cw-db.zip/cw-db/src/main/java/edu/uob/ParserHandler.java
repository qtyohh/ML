package edu.uob;

import java.util.AbstractMap;
import java.util.List;
import java.lang.String;

interface ParserHandler {
    String useDatabase(String databaseName);
    String createDatabase(String databaseName);
    String createTable(String tableName, List<String> columnName);
    String insertTableValues(String tableName, List<String> valueList);
    String selectFromTable(String tableName, List<String> wildAttribList, Condition condition);
    String updateValue(String tableName,
                       List<AbstractMap.SimpleEntry<String, String>> nameValueList,
                       Condition condition);
    String alterAdd(String tableName, String columnName);
    String alterDrop(String tableName, String columnName);
    String deleteFromTable(String tableName, Condition condition);
    String dropDatabase(String databaseName);
    String dropTable(String tableName);
    String joinTwoTable(String tableName1, String tableName2, String attributeName1, String attributeName2);
}