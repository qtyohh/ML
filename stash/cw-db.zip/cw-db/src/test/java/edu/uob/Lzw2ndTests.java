package edu.uob;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.Duration;

public class Lzw2ndTests {

    private DBServer server;

    @BeforeEach
    public void setup() {
        server = new DBServer();
    }

    private String generateRandomName() {
        String randomName = "";
        for(int i=0; i<10 ;i++) randomName += (char)(97 + (Math.random() * 25));
        return randomName;
    }

    private String sendCommandToServer(String command) {
        return assertTimeoutPreemptively(Duration.ofMillis(1000),
                () -> server.handleCommand(command),
                "Server timeout");
    }

    // ================= 合法操作测试 =================
    @Test
    public void testValidOperations() {
        // 纯数字标识符测试
        sendCommandToServer("CREATE DATABASE 314159;");
        assertTrue(sendCommandToServer("USE 314159;").contains("[OK]"));
        assertTrue(sendCommandToServer("CREATE TABLE 8675309 (911, 999);").contains("[OK]"));
        sendCommandToServer("INSERT INTO 8675309 VALUES (123, 'emergency');");
        assertTrue(sendCommandToServer("SELECT 911 FROM 8675309 WHERE 999 == 'emergency';").contains("123"));

        // 删除重建测试
        String dbName = generateRandomName();
        sendCommandToServer("CREATE DATABASE " + dbName + ";");
        sendCommandToServer("USE " + dbName + ";");
        sendCommandToServer("CREATE TABLE data (content);");
        sendCommandToServer("DROP TABLE data;");
        assertTrue(sendCommandToServer("CREATE TABLE data (newCol);").contains("[OK]"));
    }

    // ================= 非法操作测试 =================
    @Test
    public void testInvalidOperations() {
        // 删除后操作测试
        sendCommandToServer("CREATE DATABASE tempDB;");
        sendCommandToServer("DROP DATABASE tempDB;");
        assertTrue(sendCommandToServer("USE tempDB;").contains("[ERROR]"));

        // 非法标识符测试
        String[] invalidNames = {"test_db", "data-base", "2024.db"};
        for(String name : invalidNames) {
            assertTrue(sendCommandToServer("CREATE DATABASE " + name + ";").contains("[ERROR]"));
        }
    }

    // ================= 语法混淆攻击测试 =================
    @Test
    public void testSyntaxAmbiguityAttacks() {
        // 空格注入攻击
        assertTrue(sendCommandToServer("CREATE   DATABASE  stealthyDB;").contains("[OK]"));

        // 混合大小写攻击
        assertTrue(sendCommandToServer("CrEaTe DaTaBaSe caseSensitiveDB;").contains("[OK]"));

        // 分号注入攻击
        String response = sendCommandToServer("CREATE DATABASE; injected; CREATE TABLE hack;");
        assertFalse(response.contains("[OK]") && response.contains("injected"));

        // 未闭合字符串攻击
        assertFalse(sendCommandToServer("INSERT INTO test VALUES ('unclosed);").contains("[OK]"));
    }

    // ================= 边界条件测试 =================
    @Test
    public void testBoundaryConditions() {
        // 空数据库操作
        sendCommandToServer("CREATE DATABASE emptyDB;");
        sendCommandToServer("DROP DATABASE emptyDB;");
        assertTrue(sendCommandToServer("DROP DATABASE emptyDB;").contains("[ERROR]"));

        // 极值测试
        sendCommandToServer("CREATE DATABASE boundaryDB;");
        sendCommandToServer("USE boundaryDB;");
        sendCommandToServer("CREATE TABLE limits (maxVal);");
        sendCommandToServer("INSERT INTO limits VALUES (999999999999999999999999999999);");
        assertTrue(sendCommandToServer("SELECT maxVal FROM limits;").contains("999999"));
    }

    // ================= 复杂查询测试 =================
    @Test
    public void testComplexQueries() {
        sendCommandToServer("CREATE DATABASE complexDB;");
        sendCommandToServer("USE complexDB;");
        sendCommandToServer("CREATE TABLE data (value);");
        sendCommandToServer("INSERT INTO data VALUES (100);");
        sendCommandToServer("INSERT INTO data VALUES (200);");

        // 嵌套条件测试
        String query = "SELECT * FROM data WHERE (id > 0 AND value < 150) OR (id == 2);";
        String response = sendCommandToServer(query);
        System.out.println(response);
        assertTrue(response.contains("1") && response.contains("2"));

        // JOIN操作测试
        sendCommandToServer("CREATE TABLE moreData (info);");
        sendCommandToServer("INSERT INTO moreData VALUES ('info1');");
        String joinResponse = sendCommandToServer("JOIN data AND moreData ON id AND id;");
        assertTrue(joinResponse.contains("100") && joinResponse.contains("info1"));
    }

    // ================= 持久化测试 =================
    @Test
    public void testPersistence() {
        String dbName = generateRandomName();
        sendCommandToServer("CREATE DATABASE " + dbName + ";");
        sendCommandToServer("USE " + dbName + ";");
        sendCommandToServer("CREATE TABLE persistent (data);");
        sendCommandToServer("INSERT INTO persistent VALUES ('survival');");

        // 模拟服务器重启
        server = new DBServer();
        sendCommandToServer("USE " + dbName + ";");
        assertTrue(sendCommandToServer("SELECT * FROM persistent;").contains("survival"));
    }

    // ================= 高级混淆测试 =================
    @Test
    public void testAdvancedAmbiguity() {
        // 伪WHERE子句攻击
        assertFalse(sendCommandToServer("CREATE TABLE fake WHERE (id);").contains("[OK]"));

        // 运算符混淆攻击
        assertFalse(sendCommandToServer("SELECT * FROM test WHERE id ==! 5;").contains("[OK]"));

        // 属性列表越界攻击
        assertFalse(sendCommandToServer("CREATE TABLE overflow (col1, col2,);").contains("[OK]"));

        // 非法JOIN语法
        assertFalse(sendCommandToServer("JOIN table1 WITH table2 USING col;").contains("[OK]"));
    }
}