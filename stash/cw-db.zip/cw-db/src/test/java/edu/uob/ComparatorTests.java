package edu.uob;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.lang.String;

import static org.junit.jupiter.api.Assertions.*;

public class ComparatorTests {
    //test comparator
    @Test
    public void testComparator() {
        Comparator comparator;
        List<String> list = Arrays.asList("id", "a");
        List<String> inputValue;

        //str is number
        comparator = new Comparator("a", "==", "1");
        inputValue = Arrays.asList("1", "+1");
        assertTrue(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", ">", "1");
        inputValue = Arrays.asList("1", "+1.0");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", ">", "1");
        inputValue = Arrays.asList("1", "-1.0");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", ">", "1");
        inputValue = Arrays.asList("1", "1.10");
        assertTrue(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "!=", "1");
        inputValue = Arrays.asList("1", "+1.0");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "LIKE", "1");
        inputValue = Arrays.asList("1", "+11");
        assertTrue(comparator.calculate(list, inputValue));

        //str is true
        comparator = new Comparator("a", "==", "1");
        inputValue = Arrays.asList("1", "True");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "like", "1");
        inputValue = Arrays.asList("1", "true");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "!=", "1");
        inputValue = Arrays.asList("1", "true");
        assertTrue(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "<", "1");
        inputValue = Arrays.asList("1", "true");
        assertFalse(comparator.calculate(list, inputValue));

        //str is String
        comparator = new Comparator("a", "==", "1");
        inputValue = Arrays.asList("1", "'1'");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "like", "1");
        inputValue = Arrays.asList("1", "'1'");
        assertTrue(comparator.calculate(list, inputValue));


        comparator = new Comparator("a", "!=", "1");
        inputValue = Arrays.asList("1", "'1'");
        assertTrue(comparator.calculate(list, inputValue));

        //str is number
        comparator = new Comparator("a", "==", "true");
        inputValue = Arrays.asList("1", "-1");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", ">", "true");
        inputValue = Arrays.asList("1", "1.01");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "!=", "true");
        inputValue = Arrays.asList("1", "-888");
        assertTrue(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "LIKE", "true");
        inputValue = Arrays.asList("1", "1");
        assertFalse(comparator.calculate(list, inputValue));

        //str is false
        comparator = new Comparator("a", "==", "true");
        inputValue = Arrays.asList("1", "false");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", ">", "true");
        inputValue = Arrays.asList("1", "false");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "!=", "true");
        inputValue = Arrays.asList("1", "False");
        assertTrue(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "==", "false");
        inputValue = Arrays.asList("1", "FALSE");
        assertTrue(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "LIKE", "true");
        inputValue = Arrays.asList("1", "false");
        assertFalse(comparator.calculate(list, inputValue));

        //str is String 'abc'
        comparator = new Comparator("a", "==", "-1.1");
        inputValue = Arrays.asList("1", "'abc'");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", ">", "'abc'");
        inputValue = Arrays.asList("1", "'abc'");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "!=", "'abc'");
        inputValue = Arrays.asList("1", "'abc'");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "==", "'abc'");
        inputValue = Arrays.asList("1", "'abc'");
        assertTrue(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "LIKE", "'ab'");
        inputValue = Arrays.asList("1", "'abc'");
        assertTrue(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "LIKE", "'abcd'");
        inputValue = Arrays.asList("1", "'abc'");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "LIKE", "'d'");
        inputValue = Arrays.asList("1", "'abc'");
        assertFalse(comparator.calculate(list, inputValue));

        //no select column
        list = Arrays.asList("id", "b");
        comparator = new Comparator("a", "==", "'d'");
        inputValue = Arrays.asList("1", "'d'");
        assertFalse(comparator.calculate(list, inputValue));

        comparator = new Comparator("a", "like", "1");
        inputValue = Arrays.asList("1", "1");
        assertFalse(comparator.calculate(list, inputValue));

    }
}