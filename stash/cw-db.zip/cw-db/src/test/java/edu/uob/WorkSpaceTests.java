package edu.uob;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.lang.String;

import static org.junit.jupiter.api.Assertions.*;

public class WorkSpaceTests {
    DBWorkSpace workSpace;
    @Test
    public void testCreateTable() {
        workSpace = new DBWorkSpace(Paths.get("databases").toAbsolutePath().toString());
        System.out.println(workSpace.workOnCommand("use abc;"));
        //System.out.println(workSpace.workOnCommand("INSERT INTO test VALUES ('Simon', 65, TRUE);"));
        //System.out.println(workSpace.workOnCommand("INSERT INTO test VALUES ('John', 55, TRUE);"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM test WHERE (name == 'Simon' or name == 'John') and mark>=60;"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM test WHERE ((name == 'Simon') and mark>=60 or name == 'John');"));
        //System.out.println(workSpace.workOnCommand("update "));
    }

    @Test
    public void testAll() {
        workSpace = new DBWorkSpace(Paths.get("databases").toAbsolutePath().toString());
        System.out.println(workSpace.workOnCommand("CREATE DATABASE markbook;"));

        System.out.println(workSpace.workOnCommand("USE markbook;"));
        System.out.println(workSpace.workOnCommand("CREATE TABLE marks (name, mark, pass);"));
        System.out.println(workSpace.workOnCommand("INSERT INTO marks VALUES ('Simon', 65, TRUE);"));
        System.out.println(workSpace.workOnCommand("INSERT INTO marks VALUES ('Sion', 55, TRUE);"));
        System.out.println(workSpace.workOnCommand("INSERT INTO marks VALUES ('Rob', 35, FALSE);"));
        System.out.println(workSpace.workOnCommand("INSERT INTO marks VALUES ('Chris', 20, FALSE);"));

        System.out.println(workSpace.workOnCommand("CREATE TABLE coursework (task, submission);"));
        System.out.println(workSpace.workOnCommand("INSERT INTO coursework VALUES ('OXO', 3);"));
        System.out.println(workSpace.workOnCommand("INSERT INTO coursework VALUES ('DB', 1);"));
        System.out.println(workSpace.workOnCommand("INSERT INTO coursework VALUES ('OXO', 4);"));
        System.out.println(workSpace.workOnCommand("INSERT INTO coursework VALUES ('STAG', 2);"));

        System.out.println(workSpace.workOnCommand("SELECT * FROM marks;"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks WHERE name != 'Sion';"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks WHERE pass == TRUE;"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM coursework;"));
        System.out.println(workSpace.workOnCommand("JOIN coursework AND marks ON submission AND id;"));
        System.out.println(workSpace.workOnCommand("UPDATE marks SET mark = 38 WHERE name == 'Chris';"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks WHERE name == 'Chris';"));
        System.out.println(workSpace.workOnCommand("DELETE FROM marks WHERE name == 'Sion';"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks;"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks WHERE (pass == FALSE) AND (mark > 35);"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks WHERE name LIKE 'i';"));
        System.out.println(workSpace.workOnCommand("SELECT id FROM marks WHERE pass == FALSE;"));
        System.out.println(workSpace.workOnCommand("SELECT name FROM marks WHERE mark>60;"));
        System.out.println(workSpace.workOnCommand("DELETE FROM marks WHERE mark<40;"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks;"));
        System.out.println(workSpace.workOnCommand("ALTER TABLE marks ADD age;"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks;"));
        System.out.println(workSpace.workOnCommand("UPDATE marks SET age = 35 WHERE name == 'Simon';"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks;"));
        System.out.println(workSpace.workOnCommand("ALTER TABLE marks DROP pass;"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks;"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM marks;"));
        System.out.println(workSpace.workOnCommand("SELECT * FROM crew;"));
        System.out.println(workSpace.workOnCommand("SELECT height FROM marks WHERE name == 'Chris';"));
        System.out.println(workSpace.workOnCommand("DROP TABLE marks;"));
        System.out.println(workSpace.workOnCommand("DROP DATABASE markbook;"));

    }

    @Test
    public void testError() {
        workSpace = new DBWorkSpace(Paths.get("databases").toAbsolutePath().toString());
        System.out.println(workSpace.workOnCommand("/"));
    }
}