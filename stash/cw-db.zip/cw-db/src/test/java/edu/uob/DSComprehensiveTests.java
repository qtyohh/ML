package edu.uob;

import java.time.Duration;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.RepeatedTest;

public class DSComprehensiveTests {
    private DBServer server;
    private Set<String> usedNames = new HashSet<>();

    @BeforeEach
    public void setup() {
        server = new DBServer();
    }

    private String generateUniqueName() {
        String name;
        do {
            name = generateRandomName();
        } while (usedNames.contains(name));
        usedNames.add(name);
        return name;
    }

    private String generateRandomName() {
        StringBuilder name = new StringBuilder();
        for(int i=0; i<10; i++)
            name.append((char)(97 + (Math.random() * 25)));
        return name.toString();
    }

    private String sendCommand(String command) {
        return assertTimeoutPreemptively(Duration.ofMillis(1000),
                () -> server.handleCommand(command),
                "Server timeout");
    }

    @Test
    public void testDatabaseOperations() {
        String dbName = generateUniqueName();

        // Test duplicate database creation
        assertTrue(sendCommand("CREATE DATABASE " + dbName + ";").contains("[OK]"));
        assertTrue(sendCommand("CREATE DATABASE " + dbName + ";").contains("[ERROR]"));

        // Test case sensitivity
        String response = sendCommand("USE " + dbName.toUpperCase() + ";");
        /*if (response.contains("[OK]")) {
            fail("Database names should be case insensitive");
        }*/

        // Test special characters in names
        String weirdDb = "a!b@c#1_2-3";
        assertTrue(sendCommand("CREATE DATABASE " + weirdDb + ";").contains("[ERROR]"));
        assertTrue(sendCommand("DROP DATABASE " + weirdDb + ";").contains("[ERROR]"));
    }

    @RepeatedTest(5)
    public void testTableOperations() {
        String dbName = generateUniqueName();
        sendCommand("CREATE DATABASE " + dbName + ";");
        sendCommand("USE " + dbName + ";");

        // Test empty table creation
        String table1 = "t" + generateRandomName();
        assertTrue(sendCommand("CREATE TABLE " + table1 + ";").contains("[OK]"));
        // can not create existed table
        assertTrue(sendCommand("CREATE TABLE " + table1 + ";").contains("[ERROR]"));


        // Test table with various column types
        String table2 = "t" + generateRandomName();
        String createCmd = "CREATE TABLE " + table2 + " (id,name,age,height,active);";
        assertTrue(sendCommand(createCmd).contains("[OK]"));

        // Test invalid column names
        assertTrue(sendCommand("CREATE TABLE badtable (select,from,where);").contains("[ERROR]"));

        // Test maximum columns
        StringBuilder wideTable = new StringBuilder("CREATE TABLE wide (");
        for (int i=0; i<100; i++) wideTable.append("col").append(i).append(",");
        wideTable.deleteCharAt(wideTable.length()-1).append(");");
        String result = sendCommand(wideTable.toString());
        assertTrue(result.contains("[OK]"), "Should support at least 100 columns");
    }

    @Test
    public void testDataManipulation() {
        String dbName = generateUniqueName();
        sendCommand("CREATE DATABASE " + dbName + ";");
        sendCommand("USE " + dbName + ";");
        sendCommand("CREATE TABLE test (id,name,age,height, bool);");

        // Test various value types
        String[] values = {
                "('Johns', 25, 1.75, NULL)",  // Test escaped quote
                "(NULL, 'NULL', 0, 0)",         // Test NULL as value and string
                "('', -123, +45.6, TRUE)",      // Empty string and signed numbers
                "('Emoji😊', 0, 0, FALSE)"      // Unicode characters
        };

        for (String val : values) {
            String cmd = "INSERT INTO test VALUES " + val + ";";
            assertTrue(sendCommand(cmd).contains("[OK]"), "Failed on: " + cmd);
        }

        // Test value count mismatch
        assertTrue(sendCommand("INSERT INTO test VALUES ('Alice');").contains("[ERROR]"));

        // Test duplicate inserts
        sendCommand("INSERT INTO test VALUES ('Bob',30,1.80, NULL);");
        String result = sendCommand("SELECT * FROM test WHERE id == 1;");
        assertTrue(result.split("Bob").length == 1, "Should not allow duplicate IDs");
    }

    @Test
    public void testComplexQueries() {
        String dbName = generateUniqueName();
        sendCommand("CREATE DATABASE " + dbName + ";");
        sendCommand("USE " + dbName + ";");
        sendCommand("CREATE TABLE people (name,age,salary);");
        sendCommand("INSERT INTO people VALUES ('Alice',30,50000.5);");
        sendCommand("INSERT INTO people VALUES ('Bob',25,45000.0);");
        sendCommand("INSERT INTO people VALUES ('Charlie',35,NULL);");

        // Test nested conditions
        String query = "SELECT * FROM people WHERE " +
                "((age > 25 AND salary >= 45000) OR name LIKE 'A%') AND id != 3;";
        String result = sendCommand(query);
        assertTrue(result.contains("Alice") && !result.contains("Charlie"),
                "Complex query failed");

        // Test arithmetic comparisons
        assertTrue(sendCommand("SELECT * FROM people WHERE age > 30;").contains("Charlie"));
        assertTrue(sendCommand("SELECT * FROM people WHERE salary != NULL;").contains("[OK]"));

        // Test LIKE operator
        sendCommand("INSERT INTO people VALUES ('Alex',28,48000);");
        String likeResult = sendCommand("SELECT * FROM people WHERE name LIKE 'A';");
        assertTrue(likeResult.split("A").length == 3); // Alice + Alex
    }

    @Test
    public void testJoinOperations() {
        String dbName = generateUniqueName();
        sendCommand("CREATE DATABASE " + dbName + ";");
        sendCommand("USE " + dbName + ";");

        sendCommand("CREATE TABLE users (name);");
        sendCommand("CREATE TABLE orders (orderId,userId,amount);");
        sendCommand("INSERT INTO users VALUES ('Alice');");
        sendCommand("INSERT INTO users VALUES ('Bob');");
        sendCommand("INSERT INTO orders VALUES (101,1,100);");
        sendCommand("INSERT INTO orders VALUES (102,1,200);");
        sendCommand("INSERT INTO orders VALUES (103,3,300);");

        // Test valid join
        String joinCmd = "JOIN users AND orders ON id AND userId;";
        String result = sendCommand(joinCmd);
        System.out.println(result);
        assertTrue(result.contains("Alice") && result.split("Alice").length == 3, // 2 orders
                "Join failed to match records");

        // Test invalid join columns
        assertTrue(sendCommand("JOIN users AND orders ON name AND orderId;")
                .contains("[OK]"));
        assertTrue(sendCommand("JOIN users AND orders ON name AND orderId;")
                .contains("orders.userId"));
        assertTrue(sendCommand("JOIN users AND orders ON name AND orderId;")
                .contains("orders.amount"));
    }

    @Test
    public void testEdgeCases() {
        // Test empty queries
        assertTrue(sendCommand("").contains("[ERROR]"));
        assertTrue(sendCommand(";").contains("[ERROR]"));

        // Test maximum query length
        StringBuilder longQuery = new StringBuilder("CREATE DATABASE ");
        while (longQuery.length() < 10000) longQuery.append("x");
        longQuery.append(";");
        String result = sendCommand(longQuery.toString());
        assertTrue(result.contains("[OK]") || result.contains("[ERROR]"),
                "Should handle long queries gracefully");

        // Test SQL injection attempts
        String injection = "CREATE TABLE test; DROP TABLE users; --";
        assertTrue(sendCommand(injection).contains("[ERROR]"));
    }

    @Test
    public void testAlterTable() {
        String dbName = generateUniqueName();
        sendCommand("CREATE DATABASE " + dbName + ";");
        sendCommand("USE " + dbName + ";");
        sendCommand("CREATE TABLE test (name);");
        sendCommand("INSERT INTO test VALUES ('Original');");

        // Test ADD COLUMN
        sendCommand("ALTER TABLE test ADD age;");
        String result = sendCommand("SELECT * FROM test;");
        assertTrue(result.contains("age"), "New column not added");
        assertTrue(result.contains("Original\t"), "Existing data not preserved");

        // Test DROP COLUMN
        sendCommand("ALTER TABLE test DROP name;");
        result = sendCommand("SELECT * FROM test;");
        assertFalse(result.contains("name"), "Column not dropped");
        assertTrue(result.contains("1\t"), "Data not updated after drop");

        // Test invalid alterations
        assertTrue(sendCommand("ALTER TABLE test ADD 123_col;").contains("[ERROR]"));
        assertTrue(sendCommand("ALTER TABLE test DROP nonExistent;").contains("[ERROR]"));
    }
}