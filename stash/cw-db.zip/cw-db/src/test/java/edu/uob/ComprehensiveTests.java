package edu.uob;

import java.time.Duration;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * ComprehensiveTests.java
 *
 * 该测试脚本旨在全面覆盖 SQL 服务器支持的所有语法命令，
 * 包括数据库/表的创建、修改、删除、数据的插入、查询、更新、删除，以及 JOIN 操作，
 * 同时也覆盖了 WHERE 子句中各种条件（包括括号嵌套、各种比较运算符和 LIKE）的测试。
 *
 * 边界情况：
 * - 对于命令中允许的额外前后空格进行了测试；
 * - 检查缺失分号、错误的关键字拼写（内部多余空格）以及必需参数缺失时返回错误；
 * - 对 INSERT 命令测试了各种数据类型：空字符串、布尔值、整数（正负）、浮点数、NULL；
 * - 对 ALTER 命令测试了添加和删除属性，并验证 SELECT 返回的列信息。
 *
 * 注意：所有命令均应以分号结尾，否则应返回错误。测试中使用了 assertTimeoutPreemptively 来防止服务器出现无限循环的情况。
 */
public class ComprehensiveTests {
    private DBServer server;

    @BeforeEach
    public void setup() {
        server = new DBServer();
    }

    // 随机名称生成器，用于生成不会重复的数据库或表名
    private String generateRandomName() {
        StringBuilder randomName = new StringBuilder();
        for (int i = 0; i < 10; i++)
            randomName.append((char) (97 + (int) (Math.random() * 26)));
        return randomName.toString();
    }

    // 向服务器发送命令，并保证在 1000 毫秒内返回结果
    private String sendCommandToServer(String command) {
        return assertTimeoutPreemptively(Duration.ofMillis(1000), () -> server.handleCommand(command),
                "Server took too long to respond (probably stuck in an infinite loop)");
    }

    // 1. 测试数据库及表的创建和基本数据操作（INSERT、SELECT、UPDATE、DELETE）
    @Test
    public void testValidDatabaseAndTableCreation() {
        String dbName = generateRandomName();
        String response;

        // 创建并选择数据库
        response = sendCommandToServer("CREATE DATABASE " + dbName + ";");
        assertTrue(response.contains("[OK]"));
        response = sendCommandToServer("USE " + dbName + ";");
        assertTrue(response.contains("[OK]"));

        // 创建一个带属性列表的表
        response = sendCommandToServer("CREATE TABLE Students (id,name,age);");
        assertTrue(response.contains("[OK]"));

        // 插入测试数据（包含 NULL）
        response = sendCommandToServer("INSERT INTO Students VALUES (1,'Alice',20);");
        assertTrue(response.contains("[ERROR]")); // 不允许插入ID
        response = sendCommandToServer("INSERT INTO Students VALUES (2,'Bob',NULL);");
        assertTrue(response.contains("[ERROR]"));

        // 插入测试数据（包含 NULL）
        response = sendCommandToServer("INSERT INTO Students VALUES ('Alice',20);");
        assertTrue(response.contains("[OK]"));
        response = sendCommandToServer("INSERT INTO Students VALUES ('Bob',NULL);");
        assertTrue(response.contains("[OK"));

        // 查询全部数据，检查返回结果中包含插入的数据
        response = sendCommandToServer("SELECT * FROM Students;");
        assertTrue(response.contains("Alice"));
        assertTrue(response.contains("Bob"));

        // 更新操作
        response = sendCommandToServer("UPDATE Students SET age = 25 WHERE id == 1;");
        assertTrue(response.contains("[OK]"));
        response = sendCommandToServer("SELECT * FROM Students WHERE id == 1;");
        assertTrue(response.contains("25"));

        // 删除操作
        response = sendCommandToServer("DELETE FROM Students WHERE name == 'Bob';");
        assertTrue(response.contains("[OK]"));
        response = sendCommandToServer("SELECT * FROM Students;");
        assertFalse(response.contains("Bob"));
    }

    // 2. 测试创建无属性列表的表（只使用表名）
    @Test
    public void testCreateTableWithoutAttributes() {
        String dbName = generateRandomName();
        String response;
        sendCommandToServer("CREATE DATABASE " + dbName + ";");
        sendCommandToServer("USE " + dbName + ";");

        response = sendCommandToServer("CREATE TABLE EmptyTable;");
        assertTrue(response.contains("[OK]"));

        // 对空表的查询一般应返回表结构（可能只有 id 列）或为空，具体取决于你的实现
        response = sendCommandToServer("SELECT * FROM EmptyTable;");
        assertTrue(response.contains("[OK]"));
    }

    // 3. 测试 INSERT 中的各种边界值（字符串、布尔、整数、浮点、NULL）
    @Test
    public void testInsertValidAndEdgeValues() {
        String dbName = generateRandomName();
        sendCommandToServer("CREATE DATABASE " + dbName + ";");
        sendCommandToServer("USE " + dbName + ";");

        // 创建表时包含多种数据类型（注意：服务器不一定做类型检查，此处仅验证语法）
        String response = sendCommandToServer("CREATE TABLE DataTest (text,flag,number,price,empty);");
        assertTrue(response.contains("[OK]"));

        // 插入包含空字符串、布尔、负整数、正浮点数和 NULL 的数据
        response = sendCommandToServer("INSERT INTO DataTest VALUES ('', TRUE, -123, +456.789, NULL);");
        assertTrue(response.contains("[OK]"));

        response = sendCommandToServer("SELECT * FROM DataTest;");
        assertTrue(response.contains("TRUE"));
        assertTrue(response.contains("-123"));
        assertTrue(response.contains("456.789"));
    }

    // 4. 测试 SELECT 语句中复杂条件（括号嵌套、各类比较运算符以及 LIKE 运算符）
    @Test
    public void testSelectWhereComplexConditions() {
        String dbName = generateRandomName();
        sendCommandToServer("CREATE DATABASE " + dbName + ";");
        sendCommandToServer("USE " + dbName + ";");

        // 创建表并插入数据
        String response = sendCommandToServer("CREATE TABLE Complex (col1,col2,col3);");
        assertTrue(response.contains("[OK]"));
        sendCommandToServer("INSERT INTO Complex VALUES ('A', 10, TRUE);");
        sendCommandToServer("INSERT INTO Complex VALUES ('B', 20, FALSE);");
        sendCommandToServer("INSERT INTO Complex VALUES ('C', 30, TRUE);");

        // 使用括号嵌套和 AND/OR 组合条件
        response = sendCommandToServer("SELECT * FROM Complex WHERE ((col2 >= 20) OR (col2 < 10)) AND (col3 == TRUE);");
        assertTrue(response.contains("A") || response.contains("C"));

        // 测试 LIKE 运算符（注意两侧必须有空格）
        response = sendCommandToServer("SELECT * FROM Complex WHERE col1 LIKE 'A';");
        assertTrue(response.contains("A"));

        // 字段顺序
        response = sendCommandToServer("SELECT col2, id FROM Complex WHERE col1 LIKE 'A';");
        assertTrue(response.contains("col2\tid"));
    }

    // 5. 测试 UPDATE 与 DELETE 操作
    @Test
    public void testUpdateAndDelete() {
        String dbName = generateRandomName();
        sendCommandToServer("CREATE DATABASE " + dbName + ";");
        sendCommandToServer("USE " + dbName + ";");

        sendCommandToServer("CREATE TABLE Students (name,age);");
        sendCommandToServer("INSERT INTO Students VALUES ('Alice',20);");
        sendCommandToServer("INSERT INTO Students VALUES ('Bob',30);");

        // UPDATE 操作同时修改多个字段（若实现允许多个字段更新）
        String response = sendCommandToServer("UPDATE Students SET age = 28, name = 'Alicia' WHERE id == 1;");
        assertTrue(response.contains("[OK]"));

        response = sendCommandToServer("SELECT * FROM Students WHERE id == 1;");
        assertTrue(response.contains("Alicia"));
        assertTrue(response.contains("28"));

        // DELETE 操作
        response = sendCommandToServer("DELETE FROM Students WHERE name == 'Bob';");
        assertTrue(response.contains("[OK]"));
        response = sendCommandToServer("SELECT * FROM Students;");
        assertFalse(response.contains("Bob"));
    }

    // 6. 测试 JOIN 操作（两个表按公共属性联接）
    @Test
    public void testJoinOperation() {
        String dbName = generateRandomName();
        sendCommandToServer("CREATE DATABASE " + dbName + ";");
        sendCommandToServer("USE " + dbName + ";");

        // 创建两个表
        String response = sendCommandToServer("CREATE TABLE TableA (value);");
        assertTrue(response.contains("[OK]"));
        response = sendCommandToServer("CREATE TABLE TableB (description);");
        assertTrue(response.contains("[OK]"));

        // 插入数据到 TableA
        sendCommandToServer("INSERT INTO TableA VALUES ('Alpha');");
        sendCommandToServer("INSERT INTO TableA VALUES ('Beta');");

        // 插入数据到 TableB
        sendCommandToServer("INSERT INTO TableB VALUES ('First');");
        sendCommandToServer("INSERT INTO TableB VALUES ('Second');");

        // 测试正确的 JOIN 操作
        response = sendCommandToServer("JOIN TableA AND TableB ON id AND id;");
        assertTrue(response.contains("Alpha"));
        assertTrue(response.contains("Second"));
    }

    // 7. 测试 ALTER TABLE 命令（添加和删除属性）
    @Test
    public void testAlterTableOperations() {
        String dbName = generateRandomName();
        sendCommandToServer("CREATE DATABASE " + dbName + ";");
        sendCommandToServer("USE " + dbName + ";");

        // 创建表
        sendCommandToServer("CREATE TABLE Students (name,age);");
        sendCommandToServer("INSERT INTO Students VALUES ('Alice',20);");

        // 添加新属性
        String response = sendCommandToServer("ALTER TABLE Students ADD email;");
        assertTrue(response.contains("[OK]"));

        // 更新新属性数据
        response = sendCommandToServer("UPDATE Students SET email = 'alice@example.com' WHERE id == 1;");
        assertTrue(response.contains("[OK]"));
        response = sendCommandToServer("SELECT * FROM Students WHERE id == 1;");
        assertTrue(response.contains("alice@example.com"));

        // 删除已有属性
        response = sendCommandToServer("ALTER TABLE Students DROP age;");
        assertTrue(response.contains("[OK]"));
        response = sendCommandToServer("SELECT * FROM Students;");
        // 检查返回结果中不再包含 age 数据（例如 20）
        assertFalse(response.contains("20"));
    }

    // 8. 测试语法错误和必需项缺失（例如缺少分号、错误的关键字拼写、必填参数缺失）
    @Test
    public void testSyntaxErrors() {
        String response;
        // 缺少分号
        response = sendCommandToServer("CREATE DATABASE ErrorDB");
        assertTrue(response.contains("[ERROR]"));

        // 关键字内部出现多余空格（不允许拆分关键字）
        response = sendCommandToServer("CRE ATE DATABASE ErrorDB;");
        assertTrue(response.contains("[ERROR]"));

        // 必填参数缺失，例如 USE 命令后没有数据库名
        response = sendCommandToServer("USE ;");
        assertTrue(response.contains("[ERROR]"));

        // INSERT 中缺失右括号
        response = sendCommandToServer("INSERT INTO SomeTable VALUES (1,'Test';");
        assertTrue(response.contains("[ERROR]"));
    }

    // 9. 测试允许的额外空白（前后空格和多个空格分隔）是否被正确处理
    @Test
    public void testWhitespaceHandling() {
        String randomName = generateRandomName();
        String response = sendCommandToServer("   CREATE    DATABASE    " + randomName + "   ;");
        assertTrue(response.contains("[OK]"));
        response = sendCommandToServer("   USE    " + randomName + "   ;");
        assertTrue(response.contains("[OK]"));
    }
}
