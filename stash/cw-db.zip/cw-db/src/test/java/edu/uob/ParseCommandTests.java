package edu.uob;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.lang.String;

import static org.junit.jupiter.api.Assertions.*;

public class ParseCommandTests {
    //test lexer command.
    @Test
    public void testCommandLexer() {
        Command command;
        String inputCommand;
        List<String> tokens;

        inputCommand = "SeLecT 1b11b From b11 where 1b == 1.1;";
        command =new Command(inputCommand);
        assertTrue(command.isCorrectCommand());
        tokens = command.getTokens();
        System.out.println(tokens);
        System.out.println(command.isCorrectCommand());

        inputCommand = "SeLecT 1.1a From b11 where (1b >=)= -1.1a('11);'";
        command =new Command(inputCommand);
        //assertFalse(command.isCorrectCommand());
        tokens = command.getTokens();
        System.out.println(tokens);
        System.out.println(command.isCorrectCommand());

        inputCommand = "SelecT *,+1 from users where (FALSE AND((111==+11.0 and 1!=-0.1)));";
        command =new Command(inputCommand);
        //assertFalse(command.isCorrectCommand());
        tokens = command.getTokens();
        System.out.println(tokens);
        System.out.println(command.isCorrectCommand());

        inputCommand = "create table test (name,mark,123);";
        command =new Command(inputCommand);
        //assertFalse(command.isCorrectCommand());
        tokens = command.getTokens();
        System.out.println(tokens);
        System.out.println(command.isCorrectCommand());

    }

    //test use command parse in parser
    @Test
    public void testUseCommandParse() {
        DBWorkSpace workSpace = new DBWorkSpace("");
        String inputCommand;

        inputCommand = "uSe ababa123;";
        assertEquals("Change to ababa123 success.", workSpace.workOnCommand(inputCommand));

        inputCommand = "uSe database ababa123;";
        assertEquals("Error use command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "   uSe   11.234;";
        assertEquals("Error database name.", workSpace.workOnCommand(inputCommand));
    }

    //test create command parse
    @Test
    public void testCreateCommandParse() {
        DBWorkSpace workSpace = new DBWorkSpace("");
        String inputCommand;

        //outside database and table
        inputCommand = "CREAte Abc114514;";
        assertEquals("Error create command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "CREAte;";
        assertEquals("Error create command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "CREATE QTY qty;";
        assertEquals("Error create command input.", workSpace.workOnCommand(inputCommand));

        //create database
        inputCommand = "CREAte database 114514     ;";
        assertEquals("Create database: 114514 success.", workSpace.workOnCommand(inputCommand));

        inputCommand = "CREAte database 114514  (11,4,514)   ;";
        assertEquals("Error create database command.", workSpace.workOnCommand(inputCommand));

        inputCommand = "CREAte database ==   ;";
        assertEquals("Error database name input.", workSpace.workOnCommand(inputCommand));

        //create table without attribute
        inputCommand = "create table 1a1a231  ;";
        assertEquals("Create table: 1a1a231 success.", workSpace.workOnCommand(inputCommand));

        inputCommand = "create table -1  ;";
        assertEquals("Error table name input.", workSpace.workOnCommand(inputCommand));

        //create table with attribute
        inputCommand = "create table zzz (q,t1,2);";
        assertEquals("Create table: zzz success. With column: q,t1,2,",
                workSpace.workOnCommand(inputCommand));

        inputCommand = "create table zzz (q);";
        assertEquals("Create table: zzz success. With column: q,", workSpace.workOnCommand(inputCommand));

        inputCommand = "create table zzz (q,t1;";
        assertEquals("Error create table attribute input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "create table zzz (q,t1,);";
        assertEquals("Error create table attribute input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "create table zzz ();";
        assertEquals("Error create table attribute input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "create table zzz (1,1.1);";
        assertEquals("Error create table attribute input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "create table zzz ((q,t));";
        assertEquals("Error create table attribute input.", workSpace.workOnCommand(inputCommand));

    }

    //test insert command parse
    @Test
    public void testInsertCommandParse() {
        DBWorkSpace workSpace = new DBWorkSpace("");
        String inputCommand;

        inputCommand = "INSERT INTO 123 VALUES ('s @-a1.22   &', -1.1, 1, +2.33, -2, 342.325436, +5,ANd,or,NULL);";
        assertEquals("Insert into 123 success.", workSpace.workOnCommand(inputCommand));

        inputCommand = "INSERT INTO 123 VALUES ();";
        assertEquals("Error values input in insert command.", workSpace.workOnCommand(inputCommand));

        inputCommand = "INSERT INTO 123.1 VALUES (NULL);";
        assertEquals("Error table name input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "INSERT INT 123 VALUES (NULL);";
        assertEquals("Error insert command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "INSERT INTO TABLE 1ab VALUES (NULL);";
        assertEquals("Error insert command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "INSERT INTO 1ab (NULL);";
        assertEquals("Error insert command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "INSERT INTO 1ab NULL;";
        assertEquals("Error insert command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "INSERT INTO 1ab VALUES ('');";
        assertEquals("Insert into 1ab success.", workSpace.workOnCommand(inputCommand));

        inputCommand = "INSERT INTO 1ab VALUES (NULL,);";
        assertEquals("Error values input in insert command.", workSpace.workOnCommand(inputCommand));

    }

    //test condition tree
    @Test
    public void testConditionTree() {
        Condition node = new Condition();
        Command command;
        String inputCommand;

        inputCommand = "(a==True);";
        command = new Command(inputCommand);
        System.out.println(command.getTokens());
        System.out.println(node.buildTree(command.getTokens(), 0, 4, false));
        node.printTree();

        inputCommand = "a>1 AND ((b>'b' OR (c == 1)));";
        command = new Command(inputCommand);
        System.out.println(command.getTokens());
        System.out.println(node.buildTree(command.getTokens(), 0, 16, false));
        node.printTree();

    }

    //test select command parse
    @Test
    public void testSelectCommandParse() {
        DBWorkSpace workSpace = new DBWorkSpace("");
        String inputCommand;

        inputCommand = "SelecT 1,* from users where;";
        assertEquals("Error attribute in select command.", workSpace.workOnCommand(inputCommand));

        inputCommand = "SelecT 1,adc, 11c from users where;";
        assertEquals("Error condition input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "SelecT 1,adc, 11c from users where;";
        assertEquals("Error condition input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "SelecT 1,adc, 11c from users where ===;";
        assertEquals("Error condition input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "SelecT 1,adc, 11c from users where a==1(;";
        assertEquals("Error condition input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "SelecT 1,adc, 11c from users where a==1);";
        assertEquals("Error condition input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "SelecT * from users where a>1 AND ((b>'b' OR (c == 1)));";
        assertEquals("select from table: users, get: *, ", workSpace.workOnCommand(inputCommand));

    }

    //test update command parse
    @Test
    public void testUpdateCommandParse() {
        DBWorkSpace workSpace = new DBWorkSpace("");
        String inputCommand;

        inputCommand = "update 1123a set a=1,b=2,c=3 where d=4;";
        assertEquals("table: 1123a nameValueList: a = 1, b = 2, c = 3, ",
                workSpace.workOnCommand(inputCommand));

        inputCommand = "update 1123a set a=1 where d=4;";
        assertEquals("table: 1123a nameValueList: a = 1, ", workSpace.workOnCommand(inputCommand));

        inputCommand = "update 1123a sat a=1,b=2,c=3 where d=4;";
        assertEquals("Error update command input.", workSpace.workOnCommand(inputCommand));


        inputCommand = "update 1123a set where d=4;";
        assertEquals("Error name value list in update command.", workSpace.workOnCommand(inputCommand));


        inputCommand = "update 1123a set a=1,b=2,c=3, where d=4;";
        assertEquals("Error name value list in update command.", workSpace.workOnCommand(inputCommand));

    }

    //test alter command parse
    @Test
    public void testAlterCommandParse() {
        DBWorkSpace workSpace = new DBWorkSpace("");
        String inputCommand;

        inputCommand = "alter TABLE 1123 add 1;";
        assertEquals("1123 add 1", workSpace.workOnCommand(inputCommand));

        inputCommand = "alter TABLE 1123 DROP 1;";
        assertEquals("1123 drop 1", workSpace.workOnCommand(inputCommand));

        inputCommand = "alter 1123 DROP 1;";
        assertEquals("Error alter command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "alter TABLE 1123 add DROP 1;";
        assertEquals("Error alter command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "alter table 1123 add drop;";
        assertEquals("Error attribute name in alter command.", workSpace.workOnCommand(inputCommand));

    }

    //test deleter command parse
    @Test
    public void testDeleteCommandParse() {
        DBWorkSpace workSpace = new DBWorkSpace("");
        String inputCommand;

        inputCommand = "delete FROM abc12 where (a==True);";
        assertEquals("delete from abc12", workSpace.workOnCommand(inputCommand));

        inputCommand = "delete table abc12 where (a==True);";
        assertEquals("Error delete command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "delete from table 123 where (a==True);";
        assertEquals("Error table name in delete command.", workSpace.workOnCommand(inputCommand));

        inputCommand = "delete from table  where (a==True);";
        assertEquals("Error table name in delete command.", workSpace.workOnCommand(inputCommand));

        inputCommand = "delete from 123 1 > 2;";
        assertEquals("Error delete command input.", workSpace.workOnCommand(inputCommand));

        inputCommand = "delete from 123 where;";
        assertEquals("Error condition in delete command.", workSpace.workOnCommand(inputCommand));
    }

    //test drop command parse
    @Test
    public void testDropCommandParse() {
        DBWorkSpace workSpace = new DBWorkSpace("");
        String inputCommand;

        inputCommand = "drop database 123;";
        assertEquals("drop database: 123", workSpace.workOnCommand(inputCommand));

        inputCommand = "drop table 123;";
        assertEquals("drop table: 123", workSpace.workOnCommand(inputCommand));

        inputCommand = "drop table True;";
        assertEquals("Error table name in drop command.", workSpace.workOnCommand(inputCommand));
    }

    //test join command parse
    @Test
    public void testJoinCommandParse() {
        DBWorkSpace workSpace = new DBWorkSpace("");
        String inputCommand;

        inputCommand = "join table1 and table2 on 123 and 456;";
        assertEquals("join table: table1 and table: table2 on 123 and 456",
                workSpace.workOnCommand(inputCommand));

    }
}