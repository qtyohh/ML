package edu.uob;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.lang.String;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertFalse;

public class ConditionTests {
    private DBServer server;

    // Create a new server _before_ every @Test
    @BeforeEach
    public void setup() {
        server = new DBServer();
    }

    // Random name generator - useful for testing "bare earth" queries (i.e. where tables don't previously exist)
    private String generateRandomName() {
        StringBuilder randomName = new StringBuilder();
        for(int i=0; i<10 ;i++) randomName.append((char)( 97 + (Math.random() * 25.0)));
        return randomName.toString();
    }

    private String sendCommandToServer(String command) {
        // Try to send a command to the server - this call will timeout if it takes too long (in case the server enters an infinite loop)
        return assertTimeoutPreemptively(Duration.ofMillis(1000), () -> { return server.handleCommand(command);},
                "Server took too long to respond (probably stuck in an infinite loop)");
    }

    @Test
    public void errorCaseConditionTest() {
        String randomName = generateRandomName();
        String response;
        sendCommandToServer("CREATE DATABASE " + randomName + ";");
        sendCommandToServer("USE " + randomName + ";");

        sendCommandToServer("CREATE TABLE Marks (name, mark, pass);");
        sendCommandToServer("INSERT INTO marks VALUES ('Simon;{0},{1}\\t', 65, TRUE);");
        sendCommandToServer("INSERT INTO marks VALUES ('Sion', 55, TRUE);");
        sendCommandToServer("INSERT INTO marks VALUES ('Rob', 35, FALSE);");
        sendCommandToServer("INSERT INTO marks VALUES ('Chris', 20, FALSE);");

        sendCommandToServer("CREATE TABLE coursework (task, submission);");
        sendCommandToServer("INSERT INTO coursework VALUES ('OXO', 3);");
        sendCommandToServer("INSERT INTO coursework VALUES ('DB', 1);");
        sendCommandToServer("INSERT INTO coursework VALUES ('OXO', 4);");
        sendCommandToServer("INSERT INTO coursework VALUES ('STAG', 2);");

        response = sendCommandToServer("select * from marks where (mark Like 6) or (pass Like true) or (true == true);");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("select * from marks where name == \n");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("select * from marks where (or (name Like 'ROB');");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("select * from marks where (name Like ROB) xor mark != false;");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("select * from marks where ((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))))and((((((((((((((((((((name==1))))))))))))))))))));");
        System.out.println(response);
        assertTrue(response.contains("[OK]"), "A valid query was made, however an [OK] tag was not returned");
        assertFalse(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was returned");

        response = sendCommandToServer("select * from marks where (name Like 'ROB'))(();");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");


        response = sendCommandToServer("select * from marks where True;");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("select * from marks where name>'Join'ANdmark<-0;");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("update marks set mark='where;' where (((()))) and ((()))();");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("delete from marks where pass and ')' (and true);");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("delete from marks where (name!=like)(or);");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

    }

    @Test
    public void errorCaseTest() {
        String randomName = generateRandomName();
        String response;
        sendCommandToServer("CREATE DATABASE " + randomName + ";");
        sendCommandToServer("USE " + randomName + ";");

        sendCommandToServer("CREATE TABLE Marks (name, mark, pass);");
        sendCommandToServer("INSERT INTO marks VALUES ('Simon;{0},{1}\\t', 65, TRUE);");
        sendCommandToServer("INSERT INTO marks VALUES ('Sion\\n', 55, TRUE);");
        sendCommandToServer("INSERT INTO marks VALUES ('Rob', 35, FALSE);");
        sendCommandToServer("INSERT INTO marks VALUES ('Chris', 20, FALSE);");

        sendCommandToServer("CREATE TABLE coursework (task, submission);");
        sendCommandToServer("INSERT INTO coursework VALUES ('OXO', 3);");
        sendCommandToServer("INSERT INTO coursework VALUES ('DB', 1);");
        sendCommandToServer("INSERT INTO coursework VALUES ('OXO', 4);");
        sendCommandToServer("INSERT INTO coursework VALUES ('STAG', 2);");

        response = sendCommandToServer("select * from marks where (pass > false);");
        assertTrue(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertFalse(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("select * from marks where (pass==;");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("select * from marks where (pass);");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        response = sendCommandToServer("select * from coursework where (pass);");
        assertFalse(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertTrue(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        sendCommandToServer("CREATE DATABASE abc;");
        sendCommandToServer("USE abc;");
        response = sendCommandToServer("USE " + randomName + ";");
        assertTrue(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertFalse(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");

        sendCommandToServer("INSERT INTO marks VALUES ('Sionnnn', +0, TRUE);");

        response = sendCommandToServer("select * from marks where mark == 0;");
        assertTrue(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertFalse(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");
        assertTrue(response.contains("Sionnnn"));

        response = sendCommandToServer("select * from marks where mark == -0;");
        assertTrue(response.contains("[OK]"), "A valid query was made, however an [OK] tag was returned");
        assertFalse(response.contains("[ERROR]"), "A valid query was made, however an [ERROR] tag was not returned");
        assertTrue(response.contains("Sionnnn"));

    }
}