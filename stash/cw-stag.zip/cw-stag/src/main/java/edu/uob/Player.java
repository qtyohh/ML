package edu.uob;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

public class Player {
    private String name;
    private String location;
    private HashSet<String> pockets;
    int health;
    int MAX_HEALTH = 3;

    public Player(String name, String location) {
        this.name = name;
        this.location = location;
        this.pockets = new HashSet<>();
        this.health = MAX_HEALTH;
    }

    public String getName() {
        return this.name;
    }
    public String getLocation() {
        return this.location;
    }

    public HashSet<String> getPockets() {
        return this.pockets;
    }

    public int getHealth() {
        return this.health;
    }

    public void moveTo(String newLocation) {
        this.location = newLocation;
    }

    public void healthChange(int amount) {
        this.health += amount;
        if (this.health > this.MAX_HEALTH) {
            this.health = this.MAX_HEALTH;
        }
    }
    public boolean isDead() {
        return this.health <= 0;
    }

    public void reborn(String startLocation) {
        this.health = this.MAX_HEALTH;
        this.location = startLocation;
    }
    public void addPocketItem(String item) {
        this.pockets.add(item);
    }
    public void removePocketItem(String item) {
        this.pockets.remove(item);
    }
    public boolean hasPocketItem(String item) {
        return this.pockets.contains(item);
    }


}