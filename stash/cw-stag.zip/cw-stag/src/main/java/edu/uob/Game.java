package edu.uob;

import com.alexmerz.graphviz.objects.Graph;

import org.w3c.dom.Element;

import java.util.HashMap;
import java.util.HashSet;

public class Game {
    Map map;
    HashMap<String, Player> playersList;
    ActionCollection actionCollection;

    public Game(Graph entitiesGraph, Element actionsElement) {
        this.map = new Map(entitiesGraph);
        this.actionCollection = new ActionCollection(actionsElement);
        this.playersList = new HashMap<>();
    }

    public String commandWorking(String command) {
        String playerName;
        Player player = null;
        int index = command.indexOf(':');
        playerName = command.substring(0, index);
        if (!this.checkPlayerName(playerName)) {
            return "Invalid player name.";
        }
        player = this.getPlayer(playerName);

        HashSet<String> triggerWords =
                this.actionCollection.findTriggerWords(command.substring(index + 1).toLowerCase());
        HashSet<String> entityWords =
                this.map.findEntityWords(command.substring(index + 1).toLowerCase());
        HashSet<String> locationWords =
                this.map.findLocationWords(command.substring(index + 1).toLowerCase());

        if (player == null || triggerWords.isEmpty()) {
            return "Invalid command.";
        }
        String trigger = this.actionCollection.try2Action(player, triggerWords, entityWords, locationWords);
        if (trigger == null) {
            return "Error command input.";
        }
        else {
            return this.doAction(trigger, player, entityWords, locationWords);
        }

    }

    private boolean checkPlayerName(String playerName) {
        for(int i = 0; i < playerName.length(); i++) {
            char c = playerName.charAt(i);
            if (!Character.isLetter(c) && c != '-' && c != ' ' && c != '\'') {
                return false;
            }
        }
        return true;
    }

    private Player getPlayer(String playerName) {
        if (!this.playersList.containsKey(playerName)) {
            Player newPlayer = new Player(playerName, this.map.getStartLocation());
            this.playersList.put(playerName, newPlayer);
        }
        return this.playersList.get(playerName);
    }

    private String doAction(String trigger,
                            Player player,
                            HashSet<String> subjectWords,
                            HashSet<String> locationWords) {
        switch (trigger) {
            case "inv", "inventory": return this.actionInventory(player);
            case "look": return this.actionLook(player);
            case "goto": return this.actionGoto(player, locationWords);
            case "get": return this.actionGet(player, subjectWords);
            case "drop": return this.actionDrop(player, subjectWords);
            case "health": return this.actionHealth(player);
            default: return this.actionOther(trigger, player, subjectWords);
        }
    }

    private String actionInventory(Player player) {
        StringBuilder str = new StringBuilder();
        str.append("Artefacts currently being carried: ");
        if (player.getPockets().isEmpty()) {
            str.append("Nothing.");
            return str.toString();
        }

        for (String entity : player.getPockets()) {
            str.append("\n    ").append(entity);
            str.append(" : ").append(this.map.getEntity(entity).getDescription());
        }
        return str.toString();
    }

    private String actionLook(Player player) {
        Location currentLocation = this.map.getLocation(player.getLocation());
        StringBuilder str = new StringBuilder();
        str.append("Current location: ");
        str.append(currentLocation.getName()).append("\n");
        str.append(currentLocation.getDescription()).append("\n");

        str.append("Entities around you: ");
        for (Entity entity : this.map.getEntitiesOfLocation(currentLocation.getName())) {
            str.append("\n").append(entity.getName()).append(": ");
            str.append(entity.getDescription());
        }

        str.append("\nPlayers around: ");
        for (String playerName : this.playersList.keySet()) {
            if (currentLocation.getName().equalsIgnoreCase(this.playersList.get(playerName).getLocation())) {
                str.append(playerName).append(", ");
            }
        }

        str.append("\nThere are paths to: ");
        for (String edge : currentLocation.getEdges()) {
            str.append(edge).append(", ");
        }
        return str.toString();
    }

    private String actionGet(Player player, HashSet<String> subjectWords) {
        String entityName = subjectWords.iterator().next();
        StringBuilder str = new StringBuilder();
        if (this.map.findEntity(player.getLocation().toLowerCase(), entityName.toLowerCase())) {
            if(!this.map.getEntity(entityName).isArtefact()){
                str.append("Failed: ").append(entityName).append(" is not an artefact.");
                return str.toString();
            }

            player.addPocketItem(entityName);
            str.append(entityName).append(" is added to inventory.");

            StringBuilder nameStr = new StringBuilder();
            nameStr.append("Player:").append(player.getName());
            this.map.changeEntityLocation(nameStr.toString(), entityName);
        } else {
            str.append("Failed to find ").append(entityName).append(" here.");
        }
        return str.toString();
    }

    private String actionDrop(Player player, HashSet<String> subjectWords) {
        String entityName = subjectWords.iterator().next();
        StringBuilder str = new StringBuilder();
        if (player.hasPocketItem(entityName.toLowerCase())) {
            player.removePocketItem(entityName);
            this.map.changeEntityLocation(player.getLocation(), entityName);
            str.append(entityName).append(" is dropped from inventory.");
        } else {
            str.append("Failed: You don't have ").append(entityName).append(".");
        }
        return str.toString();
    }

    private String actionGoto(Player player, HashSet<String> locationWords) {
        String locationName = locationWords.iterator().next();
        Location location = this.map.getLocation(locationName);
        StringBuilder str = new StringBuilder();
        if (location!= null && this.map.isTherePathTo(player.getLocation(), locationName)) {
            player.moveTo(locationName);
            str.append("You are moving to location ");
        } else {
            str.append("Failed to move to location ");
        }
        str.append(locationName);
        str.append(".");
        return str.toString();
    }

    private String actionHealth(Player player) {
        StringBuilder str = new StringBuilder();
        str.append("Player's health: ").append(player.getHealth());
        return str.toString();
    }

    private String actionOther(String trigger,
                               Player player,
                               HashSet<String> subjectWords) {
        StringBuilder str = new StringBuilder();
        HashSet<Action> actions = this.actionCollection.getAction(trigger);
        if (actions.isEmpty()) {
            str.append("No actions found for trigger: ").append(trigger);
            return str.toString();
        }
        for (Action action : actions) {
            if (!action.findSubjectWords(subjectWords)) {
                continue;
            }
            if (!this.checkActionPerform(action, player)) {
                str.append("Failed to perform action, because some of the subjects is not here.");
            } else {
                str.append(action.getNarration());
                str.append(this.consumeEntity(action, player));
                str.append(this.productEntity(action, player));
            }
            break;
        }

        if (player.isDead()) {
            this.playerDead(player);
            str.append("\nYou died and lost all of your items, you must return to the start location of the game.");
        }

        return str.toString();
    }

    private String consumeEntity(Action action, Player player) {
        StringBuilder str = new StringBuilder();
        for (String consumeItem : action.getConsumedSet()) {
            consumeItem = consumeItem.toLowerCase();

            if (consumeItem.equalsIgnoreCase("health")) {
                player.healthChange(-1);
                str.append("\nPlayer's health decreased by 1.");
                continue;
            }

            if (this.map.getLocation(consumeItem) != null) {
                this.map.getLocation(player.getLocation()).deleteEdge(consumeItem);
                str.append("\nTrying to remove path from ");
                str.append(player.getLocation());
                str.append(" to ");
                str.append(consumeItem);
                continue;
            }

            Entity entity = this.map.getEntity(consumeItem);
            String entityLocation = entity.getLocation();
            if (entityLocation.contains("Player:")) {

                StringBuilder locationName = new StringBuilder();
                locationName.append("Player:").append(player.getName());

                if (entityLocation.equalsIgnoreCase(locationName.toString())) {
                    this.map.changeEntityLocation("storeroom", entity.getName());
                    player.removePocketItem(entity.getName());
                    str.append("\nConsume ").append(entity.getName()).append(" from pocket.");
                } else {
                    str.append("\nFailed to consume ").append(entity.getName()).append(" from other's pocket.");
                }
            }
            else {
                this.map.changeEntityLocation("storeroom", entity.getName());
                str.append("\nConsume ").append(entity.getName()).append(" from ").append(entityLocation);
            }
        }
        return str.toString();
    }

    private String productEntity(Action action, Player player) {
        StringBuilder str = new StringBuilder();
        for (String produceItem : action.getProducedSet()) {
            produceItem = produceItem.toLowerCase();

            if (produceItem.equalsIgnoreCase("health")) {
                player.healthChange(1);
                str.append("\nPlayer's health added by 1.");
                continue;
            }

            Location location = this.map.getLocation(produceItem);
            if (location != null) {
                this.map.getLocation(player.getLocation()).addEdge(location.getLowercaseName());
                str.append("\nTried to add path from ").
                        append(player.getLocation()).
                        append(" to ").
                        append(location.getName());
                continue;
            }

            Entity entity = this.map.getEntity(produceItem);
            if (entity == null) {
                str.append("\nEntity don't exist: ").append(produceItem);
                continue;
            }
            String entityLocation = entity.getLocation();

            if (entityLocation != null && entityLocation.contains("Player:")) {
                StringBuilder locationName = new StringBuilder();
                locationName.append("Player:").append(player.getName());
                if (!entityLocation.equalsIgnoreCase(locationName.toString())) {
                    str.append("\nFailed to produce ").append(entity.getName()).append(" from other's pocket.");
                }
            }
            else {
                this.map.changeEntityLocation(player.getLocation(), entity.getName());
                str.append("\nProduce ").append(entity.getName()).append(" from ").append(entityLocation);
            }
        }
        return str.toString();
    }

    private boolean checkActionPerform(Action action, Player player) {
        HashSet<String> actionSubjectWords = action.getSubjectsSet();
        for (String subjectWord : actionSubjectWords) {
            if (!player.hasPocketItem(subjectWord.toLowerCase())
                    && !this.map.findEntity(player.getLocation(), subjectWord.toLowerCase())
                    && !subjectWord.equalsIgnoreCase(player.getLocation())) {
                return false;
            }
        }
        return true;
    }

    private void playerDead(Player player) {
        for (String entity : player.getPockets()) {
            player.removePocketItem(entity);
            this.map.changeEntityLocation(player.getLocation(), entity);
        }
        player.reborn(this.map.getStartLocation());
    }

}