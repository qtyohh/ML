package edu.uob;

public class Entity extends GameEntity {
    private final String type;
    private String location;
    public Entity(String name, String description, String type, String location) {
        super(name, description);
        this.type = type;
        this.location = location;
    }
    public String getLocation() {
        return this.location;
    }
    public void changeLocation(String name) {
        this.location = name;
    }
    public boolean isArtefact() {
        return this.type.equalsIgnoreCase("artefacts");
    }
    public boolean isFurniture() {
        return this.type.equalsIgnoreCase("furniture");
    }
    public boolean isCharacter() {
        return this.type.equalsIgnoreCase("characters");
    }
}