package edu.uob;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Action {
    private String narration;
    private HashSet<String> triggersSet;
    private HashSet<String> subjectsSet;
    private HashSet<String> consumedSet;
    private HashSet<String> producedSet;
    public Action (HashSet<String> subjectsSet,
                   HashSet<String> triggersSet,
                   HashSet<String> consumedSet,
                   HashSet<String> producedSet,
                   String narration) {
        this.narration = narration;
        this.triggersSet = triggersSet;
        this.subjectsSet = subjectsSet;
        this.consumedSet = consumedSet;
        this.producedSet = producedSet;
    }
    public String getNarration() {
        return this.narration;
    }
    public HashSet<String> getTriggersSet() {
        return this.triggersSet;
    }
    public HashSet<String> getSubjectsSet() {
        return this.subjectsSet;
    }
    public HashSet<String> getConsumedSet() {
        return this.consumedSet;
    }
    public HashSet<String> getProducedSet() {
        return this.producedSet;
    }

    public boolean findSubjectWords(HashSet<String> entityNameSet) {
        for (String entityName : entityNameSet) {
            if (!this.subjectsSet.contains(entityName)) {
                return false;
            }
        }
        return true;
    }

    public boolean checkSubjectWords(HashSet<String> entityWords,
                                     HashSet<String> locationWords) {
        int actionSubjectCount = 0;
        for (String actionWord : entityWords) {
            String item = actionWord.toLowerCase();
            if (!this.subjectsSet.contains(item)) {
                return false;
            }
            actionSubjectCount++;
        }

        for (String actionWord : locationWords) {
            String item = actionWord.toLowerCase();
            if (!this.subjectsSet.contains(item)) {
                return false;
            }
            actionSubjectCount++;
        }

        return actionSubjectCount > 0;

    }
}