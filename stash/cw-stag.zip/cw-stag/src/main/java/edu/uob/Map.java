package edu.uob;

import com.alexmerz.graphviz.objects.Edge;
import com.alexmerz.graphviz.objects.Graph;
import com.alexmerz.graphviz.objects.Node;

import java.util.HashMap;
import java.util.HashSet;

public class Map {
    private HashMap<String, Location> locations;
    private HashMap<String, Entity> entities;
    private String startLocation;

    public Map(Graph entitiesGraph) {
        this.locations = new HashMap<>();
        this.entities = new HashMap<>();
        this.startLocation = null;
        for (Graph subGraph : entitiesGraph.getSubgraphs()) {
            String subGraphName = subGraph.getId().getId();
            if ("locations".equals(subGraphName)) {
                for (Graph locationInfo : subGraph.getSubgraphs()) {
                    this.initLocation(locationInfo);
                }
            } else if ("paths".equals(subGraphName)) {
                this.initEdges(subGraph);
            }
        }
        if (!this.locations.containsKey("storeroom")) {
            this.initStoreroom();
        }
    }

    public Location getLocation(String locationName) {
        return this.locations.get(locationName);
    }
    public HashSet<String> findLocationWords(String command) {
        HashSet<String> result = new HashSet<>();
        for (String locationName : locations.keySet()) {
            if (this.isContain(command, locationName)) {
                result.add(locationName);
            }
        }
        return result;
    }

    public HashSet<String> findEntityWords(String command) {
        HashSet<String> result = new HashSet<>();
        for (String entityName : entities.keySet()) {
            if (this.isContain(command, entityName)) {
                result.add(entityName);
            }
        }
        return result;
    }

    public HashSet<Entity> getEntitiesOfLocation(String locationName) {
        HashSet<Entity> result = new HashSet<>();
        for (Entity entity : entities.values()) {
            if (entity.getLocation().equalsIgnoreCase(locationName)) {
                result.add(entity);
            }
        }
        return result;
    }

    public String getStartLocation() {
        return this.startLocation;
    }

    public void changeEntityLocation(String locationName, String entityName) {
        Entity entity = entities.get(entityName);
        if (entity!= null) {
            entity.changeLocation(locationName);
        }
    }

    public boolean isTherePathTo(String start, String end) {
        return this.locations.get(start).findEdgeTo(end);
    }

    public boolean findEntity(String locationName, String itemName) {
        Entity entity = entities.get(itemName);
        if (entity == null) {
            return false;
        }
        return entity.getLocation().equalsIgnoreCase(locationName);
    }

    public Entity getEntity(String entityName) {
        return entities.get(entityName);
    }

    private void initLocation(Graph location) {

        String name = "";
        String desc = "";
        for (Node node : location.getNodes(false)) {
            if(node.getId().getId().equalsIgnoreCase("node")) {
                continue;
            }
            name = node.getId().getId();
            desc = node.getAttributes().get("description");
            break;
        }
        Location newLocation = new Location(name, desc);
        this.locations.put(newLocation.getLowercaseName(), newLocation);
        if (this.startLocation == null) {
            this.startLocation = newLocation.getName();
        }
//        System.out.println(newLocation.getName());
//        System.out.println(newLocation.getLowercaseName());
//        System.out.println(newLocation.getDescription());

        Entity newEntity;
        for (Graph  subgraph : location.getSubgraphs()) {
            String subGraphName = subgraph.getId().getId();
            for (Node node : subgraph.getNodes(false)) {
                String nodeName = node.getId().getId();
                if("node".equals(nodeName)) {
                    continue;
                }

                newEntity = new Entity(nodeName, node.getAttributes().get("description"),
                        subGraphName, newLocation.getLowercaseName());
                entities.put(nodeName.toLowerCase(), newEntity);
            }
        }
    }

    private void initEdges(Graph subGraph) {
        for (Edge edge : subGraph.getEdges()) {
            String startNode = edge.getSource().getNode().getId().getId().toLowerCase();
            String endNode = edge.getTarget().getNode().getId().getId().toLowerCase();
            this.locations.get(startNode).addEdge(endNode);
        }
    }

    private boolean isContain(String command, String name) {
        int index = command.indexOf(name);
        int endIndex = index + name.length();
        if (index == -1) {
            return false;
        }
        if ((index == 0 || command.charAt(index - 1) ==' ')
                && (endIndex == command.length() || command.charAt(endIndex) == ' ')) {
            return true;
        }
        return isContain(command.substring(index + 1), name);
    }

    private void initStoreroom() {
        Location newLocation = new Location("storeroom", "This is storeroom, read in file forgot to create one.");
        this.locations.put(newLocation.getName(), newLocation);
    }
}