package edu.uob;

import com.alexmerz.graphviz.objects.Edge;
import com.alexmerz.graphviz.objects.Graph;
import com.alexmerz.graphviz.objects.Node;

import java.util.HashMap;
import java.util.HashSet;

public class Location extends GameEntity {
    private HashSet<String> edgesSet;
    public Location(String name, String desc) {
        super(name, desc);
        edgesSet = new HashSet<>();
    }

    public void addEdge(String name) {
        edgesSet.add(name);
    }
    public void deleteEdge(String name) {
        edgesSet.remove(name);
    }
    public boolean findEdgeTo(String name) {
        return edgesSet.contains(name);
    }
    public HashSet<String> getEdges() {
        return edgesSet;
    }
}