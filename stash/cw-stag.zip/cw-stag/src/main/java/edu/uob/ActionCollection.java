package edu.uob;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class ActionCollection {
    private HashSet<Action> actions;
    private HashSet<String> basicActionSet;

    public ActionCollection (Element actionsElement) {
        this.actions = new HashSet<>();
        this.basicActionSet = new HashSet<>();
        this.addBasicActions();
        NodeList actionNodes = actionsElement.getElementsByTagName("action");
        for(int i = 0; i < actionNodes.getLength(); i++) {
            Node actionNode = actionNodes.item(i);
            if(actionNode.getNodeType() == Node.ELEMENT_NODE) {
                this.handleActionElement((Element)actionNode);
            }

        }
    }

    public HashSet<Action> getAction(String triggerName) {
        HashSet<Action> retSet = new HashSet<>();
        for (Action action : this.actions) {
            if(action.getTriggersSet().contains(triggerName)) {
                    retSet.add(action);
                }
        }
        return retSet;
    }

    public String try2Action(Player player,
                              HashSet<String> triggerWords ,
                              HashSet<String> entityWords,
                              HashSet<String> locationWords) {
        boolean correctActionFound = false;
        String trigger = null;
        for(String triggerWord : triggerWords) {
            switch (triggerWord) {
                case "inv", "inventory", "look", "health": {
                    correctActionFound = this.checkBasicActionNoSubject(entityWords, locationWords);
                    break;
                }
                case "goto": {
                    correctActionFound = this.checkBasicActionOneSubject(locationWords, entityWords);
                    break;
                }
                case "get", "drop": {
                    correctActionFound = this.checkBasicActionOneSubject(entityWords, locationWords);
                    break;
                }
                default: {
                    correctActionFound = this.checkAction(player, triggerWord, entityWords, locationWords);
                }
            }

            if (!correctActionFound) {continue;}
            if (trigger != null) {
                if (this.checkActionSame(trigger, triggerWord)) {
                    continue;
                }
                return null;
            }
            trigger = triggerWord;
        }
        return trigger;
    }

    public HashSet<String> findTriggerWords(String command) {
        HashSet<String> words = new HashSet<>();
        for (String basicAction : this.basicActionSet) {
            if(this.isContain(command, basicAction)) {
                words.add(basicAction);
            }
        }
        for (Action action : this.actions) {
            Set<String> triggerSet = action.getTriggersSet();
            for (String trigger : triggerSet) {
                if (this.isContain(command, trigger)) {
                    words.add(trigger);
                }
            }
        }
        return words;
    }

    private boolean checkBasicActionNoSubject(HashSet<String> entityWords, HashSet<String> locationWords) {
        return entityWords.isEmpty() && locationWords.isEmpty();
    }

    private boolean checkBasicActionOneSubject(HashSet<String> subjectSet1, HashSet<String> subjectSet2) {
        return subjectSet1.size() == 1 && subjectSet2.isEmpty();
    }

    private boolean checkAction(Player player,
                                String triggerWord,
                                HashSet<String> entityWords,
                                HashSet<String> locationWords) {
        HashSet<Action> actionsSet = this.getAction(triggerWord);
        boolean legalAction = false;
        for (Action action : actionsSet) {
            if (action.checkSubjectWords(entityWords, locationWords)) {
                if (legalAction) {
                    return false;
                }
                legalAction = true;
            }
        }
        return legalAction;
    }

    private boolean checkActionSame(String trigger1,
                                    String trigger2) {
        HashSet<Action> actionsSet1 = this.getAction(trigger1);
        HashSet<Action> actionsSet2 = this.getAction(trigger2);
        for (Action action1 : actionsSet1) {
            for (Action action2 : actionsSet2) {
                if (action1.equals(action2)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void handleActionElement(Element actionElement) {
        HashSet<String> triggersList = this.getElements(actionElement,"triggers");
        HashSet<String> subjectsList = this.getElements(actionElement,"subjects");
        HashSet<String> consumedList = this.getElements(actionElement,"consumed");
        HashSet<String> producedList = this.getElements(actionElement,"produced");
        String narration = "";
        NodeList narrationList = actionElement.getElementsByTagName("narration");
        for(int i = 0; i < narrationList.getLength(); i++) {
            Node elementNode = narrationList.item(i);
            narration = elementNode.getTextContent();
        }
        Action action = new Action(subjectsList, triggersList, consumedList, producedList, narration);
        for (String trigger : triggersList) {
            this.actions.add(action);
        }
    }

    private HashSet<String> getElements(Element actionElement, String tagName) {
        Element elementTag = (Element) actionElement.getElementsByTagName(tagName).item(0);
        NodeList elementList;
        if (tagName.equals("triggers")) {
            elementList = elementTag.getElementsByTagName("keyphrase");
        } else {
            elementList = elementTag.getElementsByTagName("entity");
        }

        HashSet<String> newSet = new HashSet<>();
        for (int i = 0; i < elementList.getLength(); i++) {
            Element element = (Element) elementList.item(i);
            newSet.add(element.getTextContent().toLowerCase());
        }
        return newSet;
    }

    private boolean isContain(String command, String name) {
        int index = command.indexOf(name);
        int endIndex = index + name.length();
        if (index == -1) {
            return false;
        }
        if ((index == 0 || command.charAt(index - 1) ==' ')
                && (endIndex == command.length() || command.charAt(endIndex) == ' ')) {
            return true;
        }
        return isContain(command.substring(index + 1), name);
    }

    private void addBasicActions() {
        this.basicActionSet.add("inventory");
        this.basicActionSet.add("inv");
        this.basicActionSet.add("get");
        this.basicActionSet.add("drop");
        this.basicActionSet.add("goto");
        this.basicActionSet.add("look");
        this.basicActionSet.add("health");
    }
}