package edu.uob;

public abstract class GameEntity {
    private String name;
    private String lowercaseName;
    private String description;

    public GameEntity(String name, String description) {
        this.name = name;
        this.lowercaseName = name.toLowerCase();
        this.description = description;
    }

    public String getName() {
        return this.name;
    }

    public String getLowercaseName() {
        return this.lowercaseName;
    }

    public String getDescription() {
        return this.description;
    }
}
