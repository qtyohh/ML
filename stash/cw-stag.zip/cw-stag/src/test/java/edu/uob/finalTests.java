package edu.uob;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.nio.file.Paths;
import java.time.Duration;

class finalTests {

    private GameServer server;

    // 初始化服务器，加载扩展的配置
    @BeforeEach
    void setup() {
        File entitiesFile = Paths.get("config" + File.separator + "qty-entities.dot").toAbsolutePath().toFile();
        File actionsFile = Paths.get("config" + File.separator + "qty-actions.xml").toAbsolutePath().toFile();
        server = new GameServer(entitiesFile, actionsFile);
    }

    // 发送命令并处理超时
    private String sendCommand(String command) {
        return assertTimeoutPreemptively(
                Duration.ofMillis(1000),
                () -> server.handleCommand(command),
                "Server timeout (可能进入死循环)"
        );
    }

    @Test
    public void testLowercase() {
        String response = "";
        sendCommand("qtyohh: get bug");
        response = sendCommand("qtyohh: dig forest");
        assertTrue(response.contains("chest"), "subject是location时没有正确执行");
        response = sendCommand("qtyohh: open CHEST");
        assertTrue(response.contains("chest"), "命令大小写不敏感");
        sendCommand("qtyohh: get key2");
        sendCommand("qtyohh: get bones");
        response = sendCommand("qtyohh: open key2");
        assertTrue(response.contains("house"), "应该开门");
        response = sendCommand("qtyohh: open key2");
        assertTrue(response.contains("house"), "应该能重复开门");
        sendCommand("qtyohh: open key2");
        sendCommand("qtyohh: open key2");
        response = sendCommand("qtyohh: unlock key2");
        assertTrue(response.contains("have a look!"), "错误把unlock识别为lock");
        response = sendCommand("qtyohh: lock key2");
        System.out.println(response);
        response = sendCommand("qtyohh: goto house");
        System.out.println(response);
        response = sendCommand("qtyohh: look");
        System.out.println(response);
        assertTrue(response.contains("forest"), "多次开门后一次锁门就没有路了，所以不应该进去");

        sendCommand("qtyohh: open key2");
        sendCommand("qtyohh: open key2");
        sendCommand("qtyohh: open key2");
        sendCommand("qtyohh: open key2");
        sendCommand("qtyohh: goto house");
        response = sendCommand("qtyohh: do   magic bones");
        assertTrue(response.contains("Invalid"), "多余空格匹配不成功"); // 报错信息自己改
        sendCommand("qtyohh: do magic bones");
        response = sendCommand("qtyohh: goto house");
        assertFalse(response.contains("Failed"), "自环应该可以走");
        sendCommand("qtyohh: goto house");
        sendCommand("qtyohh: goto house");
        sendCommand("qtyohh: goto house");
        sendCommand("qtyohh: goto house");
        sendCommand("qtyohh: goto house");
        sendCommand("qtyohh: goto house");
        sendCommand("qtyohh: goto house");
        response = sendCommand("qtyohh: look");
        assertTrue(response.contains("house"), "鬼打墙");

        sendCommand("qtyohh: goto forest");
        sendCommand("qtyohh: lock door with key2");
        sendCommand("qtyohh: get shit");
        sendCommand("qtyohh: goto cave");
        sendCommand("qtyohh: hit goblin");
        sendCommand("qtyohh: hit goblin");
        sendCommand("qtyohh: magic attack goblin");
        sendCommand("qtyohh: get key");
        response = sendCommand("qtyohh: open caveDoor with key2");
        assertTrue(response.contains("Error"), "用错钥匙了不应该打开"); // 报错信息自己改

        sendCommand("qtyohh: open caveDoor with key");
        sendCommand("qtyohh: goto secretsChamber");
        response = sendCommand("qtyohh: look");
        assertTrue(response.contains("secretsChamber"), "没有正确走到密室");

        response = sendCommand("qtyohh: throw shit to elf");
        response = sendCommand("qtyohh: look");
        assertTrue(response.contains("secretsChamber"), "先扣血再加血不应该似了，但好像不会测这个");
        assertFalse(response.contains("forest"), "先扣血再加血不应该似了，但好像不会测这个");
    }

    @Test
    public void testProduce() {
        String response = "";
        sendCommand("qtyohh: get bug");
        sendCommand("qtyohh: goto cave");
        response = sendCommand("qtyohh: dig forest");
        assertFalse(response.contains("chest"), "在location对不上时错误执行");
        response = sendCommand("qtyohh: dig cave");
        assertFalse(response.contains("chest"), "location错误");
        sendCommand("qtyohh: goto forest");
        sendCommand("qtyohh: goto cave");
        sendCommand("qtyohh: goto forest");
        sendCommand("qtyohh: goto cave");
        sendCommand("qtyohh: goto forest");
        sendCommand("qtyohh: goto cave");
        response = sendCommand("qtyohh: look");
        assertTrue(response.contains("cave"), "单向路径");
    }

    @Test
    public void gift() {
        String response = "";
        sendCommand("bones: look");
        sendCommand("qtyohh: dig forest");
        sendCommand("qtyohh: open chest");
        sendCommand("qtyohh: get bones");
        response = sendCommand("bones: look");
        System.out.println(response);
        assertTrue(response.contains("forest"), "好奇把玩家装兜里啥样");
    }

    @Test
    public void testComplexCommand() {
        String response = "";
        sendCommand("qtyohh: dig forest");
        sendCommand("qtyohh: open chest");
        sendCommand("qtyohh: get key2");
        response = sendCommand("qtyohh: open and unlock door");
        System.out.println(response);
        assertTrue(response.contains("have a look!"), "相同action的多个trigger不算复合");
        response = sendCommand("qtyohh: look door");
        System.out.println(response);
        assertFalse(response.contains("forest"), "无关变量");
        response = sendCommand("qtyohh: inv door");
        System.out.println(response);
        assertFalse(response.contains("key2"), "无关变量");
        response = sendCommand("qtyohh: inv look");
        System.out.println(response);
        assertTrue(response.contains("Error"), "复合变量");
    }
}