package edu.uob;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.nio.file.Paths;
import java.time.Duration;

class LzwTest1 {

    private GameServer server;

    // 初始化服务器，加载扩展的配置
    @BeforeEach
    void setup() {
        File entitiesFile = Paths.get("config" + File.separator + "extended-entities.dot").toAbsolutePath().toFile();
        File actionsFile = Paths.get("config" + File.separator + "extended-actions.xml").toAbsolutePath().toFile();
        server = new GameServer(entitiesFile, actionsFile);
    }

    // 发送命令并处理超时
    private String sendCommand(String command) {
        return assertTimeoutPreemptively(
                Duration.ofMillis(1000),
                () -> server.handleCommand(command),
                "Server timeout (可能进入死循环)"
        );
    }

    // ----------- 基础命令测试 -----------
    @Test
    void testLookAfterGoto() {
        sendCommand("alice: goto forest");
        String response = sendCommand("alice: look");
        assertTrue(response.contains("key"), "Forest中应包含钥匙");
        assertTrue(response.contains("tree"), "Forest中应有松树");
    }

    @Test
    void testGetAndDrop() {
        sendCommand("bob: get axe");
        String inv = sendCommand("bob: inv");
        assertTrue(inv.contains("axe"), "库存应有斧头");

        sendCommand("bob: drop axe");
        String look = sendCommand("bob: look");
        assertTrue(look.contains("axe"), "丢弃后axe应回到当前房间");
    }

    // ----------- 自定义动作测试 -----------
    @Test
    void testOpenTrapdoor() {
        // 前置：从forest获取key，返回cabin
        sendCommand("eve: goto forest");
        sendCommand("eve: get key");
        sendCommand("eve: goto cabin");

        String response = sendCommand("eve: unlock trapdoor with key");
        assertTrue(response.contains("cellar"), "应解锁地窖并显示描述");

        // 验证路径是否生效
        sendCommand("eve: goto cellar");
        String look = sendCommand("eve: look");
        assertTrue(look.contains("elf"), "应看到地窖中的精灵");
    }

    @Test
    void testChopTreeAndBridge() {
        // 获取斧头并砍树
        sendCommand("charlie: get axe");
        sendCommand("charlie: goto forest");
        sendCommand("charlie: chop tree");

        // 验证log生成
        String inv = sendCommand("charlie: inv");
        assertFalse(inv.contains("log"), "log不应在库存中");
        String lookForest = sendCommand("charlie: look");
        assertTrue(lookForest.contains("log"), "log应出现在forest");
        sendCommand("charlie: get log");

        // 移动到河岸并建造桥
        sendCommand("charlie: goto riverbank");
        sendCommand("charlie: bridge river with log");
        String lookRiver = sendCommand("charlie: look");
        assertTrue(lookRiver.contains("clearing"), "应生成通往clearing的路径");
    }

    // ----------- 多玩家场景测试 -----------
    @Test
    void testMultiPlayerInventory() {
        sendCommand("dave: get potion");
        sendCommand("eve: get axe");

        String daveInv = sendCommand("dave: inv");
        assertTrue(daveInv.contains("potion"), "Dave应有药水");
        String eveInv = sendCommand("eve: inv");
        assertTrue(eveInv.contains("axe"), "Eve应有斧头");
    }

    // ----------- 健康系统测试 -----------
    @Test
    void testHealthSystem() {
        // 初始健康为3
        String health = sendCommand("frank: health");
        assertTrue(health.contains("3"), "初始健康应为3");

        // 攻击精灵导致健康减少
        sendCommand("frank: goto forest");
        sendCommand("frank: get key");
        sendCommand("frank: goto cabin");
        sendCommand("frank: open with key");
        sendCommand("frank: goto cellar");
        sendCommand("frank: attack elf");
        health = sendCommand("frank: health");
        assertTrue(health.contains("2"), "攻击后健康应为2");

        // 喝药水恢复
        sendCommand("frank: goto cabin");
        sendCommand("frank: get potion"); // 需先返回cabin获取
        sendCommand("frank: drink potion");
        health = sendCommand("frank: health");
        assertTrue(health.contains("3"), "喝药后健康应恢复至3");
    }

    @Test
    void testPlayerDeathReset() {
        sendCommand("grace: attack elf"); // 健康-1 (初始3→2)
        sendCommand("grace: attack elf"); // 健康-1 (2→1)
        sendCommand("grace: attack elf"); // 健康-1 (1→0)

        String response = sendCommand("grace: look");
        assertTrue(response.contains("cabin"), "死亡后应重置到cabin");
        String inv = sendCommand("grace: inv");
        assertFalse(inv.contains("potion"), "死亡后库存应清空");
    }

    // ----------- 错误处理测试 -----------
    @Test
    void testInvalidCommand() {
        String response = sendCommand("hack: fly");
        assertTrue(response.contains("Invalid"), "无效命令应返回错误");
    }

    @Test
    void testAmbiguousAction() {
        // 假设存在多个"open"动作
        sendCommand("ivan: get key");
        String response = sendCommand("ivan: open");
        assertTrue(response.contains("Error"), "歧义命令应提示");
    }

    // 在LzwTest1类中添加以下测试方法

    // ----------- 边界条件测试 -----------
    @Test
    void testInventoryLimit() {
        // 测试库存容量边界（假设库存无上限，但需验证多次操作稳定性）
        sendCommand("edgeA: get axe");
        sendCommand("edgeA: get potion");
        sendCommand("edgeA: get coin");
        String inv = sendCommand("edgeA: inv");
        assertTrue(inv.contains("axe") && inv.contains("potion") && inv.contains("coin"),
                "应支持携带多个物品");
    }

    @Test
    void testDuplicateGetDrop() {
        // 重复拾取/丢弃同一物品
        sendCommand("edgeB: get axe");
        sendCommand("edgeB: drop axe");
        sendCommand("edgeB: get axe");
        String inv = sendCommand("edgeB: inv");
        assertTrue(inv.contains("axe"), "应支持重复拾取已丢弃物品");

        String response = sendCommand("edgeB: get axe");
        assertTrue(response.contains("Failed"), "重复拾取同一物品应失败");
    }

    @Test
    void testInvalidPathNavigation() {
        // 尝试非法路径移动
        sendCommand("edgeC: goto cellar"); // 未解锁时应失败
        String response = sendCommand("edgeC: look");
        assertFalse(response.contains("elf"), "未解锁地窖前不应能进入");

        sendCommand("edgeD: goto clearing"); // 无直接路径
        response = sendCommand("edgeD: look");
        assertTrue(response.contains("cabin"), "非法移动应留在原地");
    }

    @Test
    void testHealthBoundaries() {
        // ------ 测试健康满值时操作 ------
        sendCommand("edgeE: drink potion"); // 初始健康为3，喝药水无效
        String health = sendCommand("edgeE: health");
        assertTrue(health.contains("3"), "健康满时喝药水不应改变数值");

        // ------ 测试健康归零触发重置 ------
        // 前置：移动到cellar（需要钥匙操作）
        sendCommand("edgeE: goto forest");
        sendCommand("edgeE: get key");
        sendCommand("edgeE: goto cabin");
        sendCommand("edgeE: unlock trapdoor with key");
        sendCommand("edgeE: goto cellar");

        // 连续攻击精灵触发死亡
        sendCommand("edgeE: attack elf"); // 3 -> 2
        sendCommand("edgeE: attack elf"); // 2 -> 1
        sendCommand("edgeE: attack elf"); // 1 -> 0 (触发重置)

        // 验证死亡后状态
        String look = sendCommand("edgeE: look");
        assertTrue(look.contains("cabin"), "死亡后应返回起始点"); // 检查位置重置
        health = sendCommand("edgeE: health");
        assertTrue(health.contains("3"), "死亡后健康应恢复至3"); // 检查健康重置
        String inv = sendCommand("edgeE: inv");
        assertFalse(inv.contains("key"), "死亡后应清空库存"); // 检查库存清空

        // ------ 测试死亡后再次受伤 ------
        // 重新前往cellar并攻击
        sendCommand("edgeE: goto cellar");
        sendCommand("edgeE: attack elf"); // 3 -> 2
        health = sendCommand("edgeE: health");
        assertTrue(health.contains("2"), "重置后应能再次减少健康值");
    }

    @Test
    void testConcurrentEntityAccess() {
        // 多玩家竞争操作同一实体
        sendCommand("raceA: get axe");
        String response = sendCommand("raceB: get axe");
        assertTrue(response.contains("Failed"), "其他玩家应无法获取已被持有的物品");

        sendCommand("raceA: drop axe");
        sendCommand("raceB: get axe");
        String inv = sendCommand("raceB: inv");
        assertTrue(inv.contains("axe"), "应能获取其他玩家丢弃的物品");
    }

    @Test
    void testSpecialCharacterUsername() {
        // 特殊字符用户名
        String response = sendCommand("a!b@c#: look");
        assertTrue(response.contains("Invalid"), "应拒绝非法用户名");

        response = sendCommand("O'Conner-a: look");
        assertFalse(response.contains("Invalid"), "应允许合法特殊字符");
    }

    @Test
    void testStorageRoomIsolation() {
        // 尝试直接操作存储室实体
        sendCommand("edgeF: goto storeroom");
        String response = sendCommand("edgeF: look");
        assertFalse(response.contains("storeroom"), "应无法到达存储室");

        // 验证存储室实体初始状态
        sendCommand("edgeG: bridge river"); // 需要log（在存储室）
        response = sendCommand("edgeG: look");
        assertFalse(response.contains("clearing"), "未获取log前应无法生成路径");
    }

    @Test
    void testPartialActionMatching() {
        // ----------- 前置条件：获取钥匙并返回cabin -----------
        // 1. 移动到forest获取key
        sendCommand("edgeH: goto forest");
        sendCommand("edgeH: get key");
        // 2. 返回cabin（trapdoor在此处）
        sendCommand("edgeH: goto cabin");

        // ----------- 测试最小化命令匹配 -----------
        // 场景1：仅提供触发词+一个实体（trapdoor在当前位置，key在库存）
        String response = sendCommand("edgeH: unlock trapdoor");
        assertTrue(response.contains("cellar"), "应支持触发词+一个实体匹配");

        // 场景2：验证路径是否生效
        sendCommand("edgeH: goto cellar");
        String look = sendCommand("edgeH: look");
        assertTrue(look.contains("elf"), "应成功进入生成的地窖");

        // ----------- 边界测试：缺少必要实体 -----------
        // 清空key后尝试相同命令
        sendCommand("edgeH: goto cabin");
        sendCommand("edgeH: drop key");
        response = sendCommand("edgeH: unlock trapdoor");
        assertTrue(response.contains("Failed"), "缺少key时应拒绝动作");
    }

    @Test
    void testCaseInsensitiveEntityNames() {
        // 大小写混合实体名测试
        sendCommand("edgeI: GET AxE");
        sendCommand("edgeI: DROP aXe");
        String look = sendCommand("edgeI: look");
        assertTrue(look.contains("axe"), "应正确处理大小写混合命令");
    }

    // ----------- Task 9 命令灵活性测试 -----------
    @Test
    void testCaseInsensitivity() {
        // 混合大小写测试（合法用户名）
        sendCommand("Flex-One: GeT AxE");
        sendCommand("Flex-One: DrOp aXe");
        String look = sendCommand("Flex-One: LOOK");
        assertTrue(look.contains("axe"), "应支持大小写混合命令");

        // 大写触发词+实体名测试（合法用户名）
        sendCommand("Flex-Two: GOTO FOREST");
        String response = sendCommand("Flex-Two: lOOk");
        assertTrue(response.contains("tree"), "应解析大写位置名称");
    }

    @Test
    void testDecoratedCommands() {
        // 含装饰词命令测试（合法用户名）
        sendCommand("User-Alice: please kindly drop the shiny axe here");
        String look = sendCommand("User-Alice: look");
        assertTrue(look.contains("axe"), "应忽略装饰词");

        // 复杂修饰结构测试（合法用户名）
        sendCommand("User-Bob: I would like to use this axe to chop that big tree");
        String response = sendCommand("User-Bob: look");
        assertTrue(response.contains("log"), "应解析带修饰结构的命令");
    }

    @Test
    void testWordOrderVariations() {
        // 不同词序测试（合法用户名）
        sendCommand("User-Eve: with axe chop tree");
        String logCheck1 = sendCommand("User-Eve: look");
        assertTrue(logCheck1.contains("log"), "应支持倒序命令");

        sendCommand("User-Frank: tree chop using axe");
        String logCheck2 = sendCommand("User-Frank: look");
        assertTrue(logCheck2.contains("log"), "应支持自由词序");
    }

    @Test
    void testPartialCommands() {
        // 部分实体测试（需前置条件，合法用户名）
        sendCommand("User-Hank: goto forest");
        sendCommand("User-Hank: get key");
        sendCommand("User-Hank: goto cabin");
        sendCommand("User-Hank: unlock with key"); // 需要trapdoor在当前位置
        String cellarCheck = sendCommand("User-Hank: look");
        assertTrue(cellarCheck.contains("cellar"), "应支持仅触发词+隐含实体");
    }

    @Test
    void testExtraneousEntities() {
        // 多余实体测试（合法用户名）
        sendCommand("User-Ivy: get axe from cabin using hands");
        String inv = sendCommand("User-Ivy: inv");
        assertFalse(inv.contains("axe"), "应拒绝含额外实体的命令");

        // 动作命令含无关实体（合法用户名）
        sendCommand("User-John: open trapdoor with key and hammer");
        String response = sendCommand("User-John: look");
        assertFalse(response.contains("cellar"), "应拒绝多余实体");
    }

    @Test
    void testAmbiguousCommands() {
        // 设置歧义场景（合法用户名）
        sendCommand("User-King: get key");
        String response = sendCommand("User-King: open"); // 可能匹配多个动作
        assertTrue(response.contains("Error") || response.contains("multiple"),
                "应检测到歧义命令");
    }

    @Test
    void testCompositeCommands() {
        // 复合命令测试（合法用户名）
        sendCommand("User-Liam: get axe and coin");
        String inv = sendCommand("User-Liam: inv");
        assertFalse(inv.contains("axe") && inv.contains("coin"), "应拒绝复合命令");

        sendCommand("User-Mia: get axe");
        sendCommand("User-Mia: goto forest");
        sendCommand("User-Mia: look");
        sendCommand("User-Mia: inv");
        sendCommand("User-Mia: chop tree then goto cabin");
        String response = sendCommand("User-Mia: look");
        assertFalse(response.contains("log"), "应拒绝连续动作命令");
    }

    @Test
    void testEdgeCaseCommands() {
        // 边界命令格式测试（保留非法用户名测试）
        sendCommand(": ''"); // 空用户名测试
        sendCommand("Invalid-User1: :::"); // 非法命令格式（但用户名为合法）
        sendCommand("12345: 12345"); // 纯数字用户名测试（故意非法）

        // 验证纯数字用户名被拒绝
        String response = sendCommand("12345: look");
        assertTrue(response.contains("Invalid"), "应拒绝数字用户名");
    }

    @Test
    void testMultiLanguageMixing() {
        // 混合语言测试（用户名合法但命令含非英文字符）
        sendCommand("User-Nina: 获取axe"); // 中英混合命令
        String inv = sendCommand("User-Nina: inv");
        assertFalse(inv.contains("axe"), "应拒绝非英文字符命令"); // 根据需求调整断言
    }

    @Test
    void testImplicitSubjectResolution() {
        // 隐式实体解析测试（合法用户名）
        sendCommand("User-Oscar: get axe");
        sendCommand("User-Oscar: goto forest");

        // 当前房间有tree，库存有axe
        sendCommand("User-Oscar: chop axe"); // 应解析为chop tree with axe
        String response = sendCommand("User-Oscar: look");
        assertTrue(response.contains("log"), "应通过上下文解析隐式实体");
    }
}